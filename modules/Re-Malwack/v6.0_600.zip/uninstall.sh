rm -rf /data/adb/Re-Malwack
rm -f /data/adb/ksud/bin/rmlwk
rm -f /data/adb/apd/bin/rmlwk
