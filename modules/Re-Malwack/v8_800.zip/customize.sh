ui_print '           ____            __         __  '
ui_print '          / __ \____ ___  / /      __/ /__'
ui_print '         / /_/ / __ `__ \/ / | /| / / //_/'
ui_print '        / _, _/ / / / / / /| |/ |/ / ,<   '
ui_print '       /_/ |_/_/ /_/ /_/_/ |__/|__/_/|_|  '                   
ui_print " "
ui_print "   Welcome to Re-Malwack installation wizard!"
sleep 0.2
ui_print ""
ui_print " ----------------------------------"
ui_print "                                   \ "
ui_print ""
sleep 0.2
ui_print "- ⚙️ Module Version: $(grep_prop version $MODPATH/module.prop)"
sleep 0.2
ui_print "- 📱 Device Brand: $(getprop ro.product.brand)"
sleep 0.2
ui_print "- 📱 Device Model: $(getprop ro.product.model)"
sleep 0.2
ui_print "- 🤖 Android Version: $(getprop ro.build.version.release)"
sleep 0.2
ui_print "- 🏹 Device Arch: $(getprop ro.product.cpu.abi)"
sleep 0.2
ui_print "- 🛠 Kernel version: $(uname -r)"
sleep 0.2

# Detect Root Manager
root_manager=""
root_version=""
command -v magisk >/dev/null 2>&1 && root_manager="Magisk/Variants" && root_version="$MAGISK_VER"
[ "$KSU" = "true" ] && root_manager="KernelSU" && root_version="$KSU_VER_CODE"
[ "$APATCH" = "true" ] && root_manager="APatch" && root_version="$(cat "/data/adb/ap/version")"

# Output
if [ -n "$root_version" ]; then
    ui_print "- 🔓 Root Manager: $root_manager ($root_version)"
else
    ui_print "- 🔓 Root Manager: $root_manager"
fi
sleep 0.2
ui_print "- ⌛ Current Time: $(date "+%d, %b - %H:%M %Z")"
sleep 0.2
ui_print ""
sleep 0.2
ui_print "                                    /"
ui_print " ----------------------------------"
ui_print " "

# abort in recovery
$BOOTMODE || abort "[!] Not supported to install in recovery"

# check if adaway is detected or not.
pm list packages | grep -q org.adaway && abort "[✗] Adaway detected, Please uninstall to prevent conflicts, backup your setup optionally before uninstalling in case you want to import your setup."

# Add a persistent directory to save configuration
ui_print "[*] Preparing Re-Malwack environment"
persistent_dir="/data/adb/Re-Malwack"
config_file="$persistent_dir/config.sh"
mkdir -p "$persistent_dir"
touch "$config_file"
for type in block_porn block_gambling block_fakenews block_social block_trackers block_safebrowsing daily_update adblock_switch action_mode; do
    grep -q "^$type=" "$config_file" || echo "$type=0" >> "$config_file"
    touch "$persistent_dir/blacklist.txt"
    touch "$persistent_dir/whitelist.txt"
done

detect_key_press() {
    timeout_seconds=10
    total_options=${1:-2}
    recommended_option=${2:-1}

    current=1
    start_time=$(date +%s)

    ui_print "[i] Vol+ = switch, Vol- = select (timeout ${timeout_seconds}s, default: $recommended_option)"
    ui_print "Current choice: $current"

    while :; do
        now=$(date +%s)
        if [ $((now - start_time)) -ge "$timeout_seconds" ]; then
            ui_print "[!] Timeout. Auto-selecting option: $recommended_option"
            return "$recommended_option"
        fi

        # Block until we get any input
        ev="$(getevent -qlc 1 2>/dev/null)" || continue

        case "$ev" in
            *KEY_VOLUMEUP*DOWN*)
                current=$((current + 1))
                [ "$current" -gt "$total_options" ] && current=1
                ui_print "- Current choice: $current"
                ;;

            *KEY_VOLUMEDOWN*DOWN*)
                ui_print "- Selected option: $current"
                return "$current"
                ;;

            # Ignore other noise
            *) : ;;
        esac
    done
}

# set permissions
chmod +x $MODPATH/*.sh


# Initialize hosts files
mkdir -p $MODPATH/system/etc
rm -rf $persistent_dir/logs/* 2>/dev/null
rm -rf $persistent_dir/cache/* 2>/dev/null


compare_sources() {
    awk '!/^#|^$/ {print $1}' "$1" | sort > "$persistent_dir/tmp_cmp1"
    awk '!/^#|^$/ {print $1}' "$2" | sort > "$persistent_dir/tmp_cmp2"
    cmp -s "$persistent_dir/tmp_cmp1" "$persistent_dir/tmp_cmp2"
    res=$?
    rm -f "$persistent_dir/tmp_cmp1" "$persistent_dir/tmp_cmp2"
    return $res
}

update_profile() {
    local prof_file="$1"
    local dest_file="$2"
    
    if [ ! -s "$dest_file" ]; then
        cp -f "$prof_file" "$dest_file"
        return
    fi
    
    awk '
    NR==FNR {
        if (/^# OFF # /) {
            off_urls[$4] = 1
        }
        next
    }
    {
        if (/^# OFF # /) {
            url = $4
        } else if ($1 !~ /^#/) {
            url = $1
            if (off_urls[url] == 1) {
                $0 = "# OFF # " $0
            }
        } else {
            url = ""
        }
        
        if (url == "") {
            print $0
            next
        }
        
        if (!seen[url]++) {
            print $0
        }
    }
    ' "$dest_file" "$prof_file" > "${dest_file}.tmp"
    
    mv -f "${dest_file}.tmp" "$dest_file"
}

mem_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
if [ -z "$mem_kb" ]; then
    mem_kb=4000000
fi

if [ "$mem_kb" -lt 3145728 ]; then
    detected_profile="lite"
elif [ "$mem_kb" -lt 6291456 ]; then
    detected_profile="balanced"
else
    detected_profile="aggressive"
fi

current_profile=""
if [ -f "$config_file" ]; then
    current_profile=$(grep "^profile=" "$config_file" 2>/dev/null | cut -d= -f2)
fi

if [ ! -s "$persistent_dir/sources.txt" ]; then
    update_profile "$MODPATH/profiles/${detected_profile}.txt" "$persistent_dir/sources.txt"
    sed -i '/^profile=/d' "$config_file"
    echo "profile=$detected_profile" >> "$config_file"
    ui_print "[*] Auto-selected profile: $detected_profile"
else
    if [ -z "$current_profile" ]; then
        if compare_sources "$persistent_dir/sources.txt" "$MODPATH/profiles/default.txt"; then
            update_profile "$MODPATH/profiles/${detected_profile}.txt" "$persistent_dir/sources.txt"
            sed -i '/^profile=/d' "$config_file"
            echo "profile=$detected_profile" >> "$config_file"
            ui_print "[*] Auto-selected profile: $detected_profile"
        else
            sed -i '/^profile=/d' "$config_file"
            echo "profile=custom" >> "$config_file"
            ui_print "[*] Customized hosts sources detected, profile has been set to custom."
        fi
    else
        if [ "$current_profile" = "custom" ]; then
            ui_print "[*] Custom profile detected, keeping hosts sources as is."
        else
            if [ -f "$MODPATH/profiles/${current_profile}.txt" ]; then
                update_profile "$MODPATH/profiles/${current_profile}.txt" "$persistent_dir/sources.txt"
                ui_print "[*] Updating hosts sources for your $current_profile profile."
            else
                ui_print "[!] Detected missing profile $current_profile, reverting to $detected_profile."
                update_profile "$MODPATH/profiles/${detected_profile}.txt" "$persistent_dir/sources.txt"
                sed -i "/^profile=/profile=$detected_profile/d" "$config_file"
            fi
        fi
    fi
fi

# Import from other ad-block modules (All respect to other ad-block modules developers)
. $MODPATH/import.sh

awk '
{
    if (/^# OFF # /) {
        url = $4
    } else if ($1 !~ /^#/) {
        url = $1
    } else {
        url = ""
    }
    
    if (url == "") {
        print $0
        next
    }
    
    if (!seen[url]++) {
        print $0
    }
}' "$persistent_dir/sources.txt" > "$persistent_dir/sources.txt.tmp"
mv -f "$persistent_dir/sources.txt.tmp" "$persistent_dir/sources.txt"

if ping -c 1 -w 5 8.8.8.8 &>/dev/null; then
    # Initialize
    . $persistent_dir/config.sh
    [ "$adblock_switch" -eq 1 ] && {
        echo "[i] Detected adblock pause, auto resuming before updating hosts..."
        mv -f "$persistent_dir/hosts.bak" "/data/adb/modules/Re-Malwack/system/etc/hosts"
        sed -i "s/^adblock_switch=1/adblock_switch=0/" $persistent_dir/config.sh
    }
    if ! sh $MODPATH/rmlwk.sh --update-hosts --quiet; then
        ui_print "[✗] Failed to initialize script"
        # Extract version from module.prop
        module_version=$(grep_prop version $MODPATH/module.prop)

        # Check if it's a test release and extract PR/commit info
        if echo "$module_version" | grep -q "\-test.*(.*@.*)"; then
            # Extract base version commit hash & branch (ex: 5ex77xx@main) from version string
            base_version=$(echo "$module_version" | sed 's/-test.*//')
            build_id=$(echo "$module_version" | sed 's/.*(\(.*\)).*/\1/' | sed 's/\//_/g')
            tarFileName="/sdcard/Download/Re-Malwack_${base_version}-${build_id}_install_log_$(date +%Y-%m-%d_%H%M%S).tar.gz"
        else
            # Regular release version
            clean_version=$(echo "$module_version" | sed 's/\//_/g')
            tarFileName="/sdcard/Download/Re-Malwack_${clean_version}_install_log_$(date +%Y-%m-%d_%H%M%S).tar.gz"
        fi

        tar -czvf ${tarFileName} --exclude="$persistent_dir" -C $persistent_dir logs
        # cleanup in case of failure (in worst cases on first install)
        [ -d /data/adb/modules/Re-Malwack ] || rm -rf /data/adb/Re-Malwack
        abort "[i] Logs are saved in ${tarFileName}"
    fi
else
    ui_print "[i] No internet connection, skipping hosts initialization. You may initialize it later after reboot."
    # In case of module update without internet while there's an existing hosts file
        # We don't want to delete user's existing hosts file, so we just move it to the new location if it exists
        # otherwise we just create an empty hosts file to prevent potential issues.
    if [ ! -f /data/adb/modules/Re-Malwack/system/etc/hosts ]; then
        printf "127.0.0.1 localhost\n::1 localhost" > $MODPATH/system/etc/hosts
        status_msg="Status: Awaiting reboot 🔃"
        touch "$persistent_dir/mode_ready"
    else
        ui_print "[*] migrating existing hosts file to module directory"
        mv -f /data/adb/modules/Re-Malwack/system/etc/hosts $MODPATH/system/etc/hosts
        status_msg="Status: Reboot required to apply updates 🔃"
    fi
    chmod 0644 $MODPATH/system/etc/hosts
    sed -i "s/^description=.*/description=$status_msg/" "$MODDIR/module.prop"
fi

# Create symlink on install for ksu/ap
for i in /data/adb/ap/bin /data/adb/ksu/bin; do
    [ -d "$i" ] && ln -sf "/data/adb/modules/Re-Malwack/rmlwk.sh" "$i/rmlwk"
done

# Cleanup
rm -f $MODPATH/import.sh && rm -rf $MODPATH/bin