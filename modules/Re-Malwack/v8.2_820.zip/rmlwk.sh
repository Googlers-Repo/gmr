#!/system/bin/sh

# Welcome to the main script of the module :)
# Side notes: Literally everything in this module relies on this script you're checking right now.
# customize.sh (installer script), action script and even WebUI!
# Now enjoy reading the code
# - ZG089, Founder of Re-Malwack.


# ====== Variables ======
quiet_mode=0
is_zn_detected=0
persist_dir="/data/adb/Re-Malwack"
zn_module_dir="/data/adb/modules/hostsredirect"
REALPATH=$(readlink -f "$0")
MODDIR=$(dirname "$REALPATH")
system_hosts="/system/etc/hosts"
tmp_hosts="/data/local/tmp/hosts"
version=$(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2-)
LOGFILE="$persist_dir/logs/Re-Malwack_$(date +%Y-%m-%d_%H%M%S).log"

# ====== Pre-config ======

# 1 - Sourcing config file
. $persist_dir/config.sh
# 2 - creating logs dir in case if not created
mkdir -p "$persist_dir/logs"

# ====== Functions ======
rmlwk_banner() {
    [ "$quiet_mode" -eq 1 ] && return
    clear
    if [ "$(date +%m%d)" = "0401" ]; then
        printf '\033[0;31m'
        printf "    ____             __  ___      __                        \n"
        printf "   / __ \___        /  |/  /___ _/ /      ______ _________  \n"
        printf "  / /_/ / _ \______/ /|_/ / __ `/ / | /| / / __ `/ ___/ _ \ \n"
        printf " / _, _/  __/_____/ /  / / /_/ / /| |/ |/ / /_/ / /  /  __/ \n"
        printf "/_/ |_|\___/     /_/  /_/\__,_/_/ |__/|__/\__,_/_/   \___/  \n"
        printf '\033[0m'
    else
        if command -v shuf >/dev/null 2>&1; then
            random_index=$(shuf -i 1-2 -n 1)
        else
            random_index=$(( ($(date +%s) % 2) + 1 ))
        fi
        case "$random_index" in
            1)
                printf '\033[0;31m'
                printf "    ____             __  ___      __                    __            \n"
                printf "   / __ \\___        /  |/  /___ _/ /      ______ ______/ /__          \n"
                printf "  / /_/ / _ \\______/ /|_/ / __ \`/ / | /| / / __ \`/ ___/ //_/       \n"
                printf " / _, _/  __/_____/ /  / / /_/ / /| |/ |/ / /_/ / /__/ ,<              \n"
                printf "/_/ |_|\\___/     /_/  /_/\\__,_/_/ |__/|__/\\__,_/\\___/_/|_|      \n"
                ;;
            2)
                printf '\033[0;31m'
                printf "██████╗ ███████╗    ███╗   ███╗ █████╗ ██╗     ██╗    ██╗ █████╗  ██████╗██╗  ██╗\n"
                printf "██╔══██╗██╔════╝    ████╗ ████║██╔══██╗██║     ██║    ██║██╔══██╗██╔════╝██║ ██╔╝\n"
                printf "██████╔╝█████╗█████╗██╔████╔██║███████║██║     ██║ █╗ ██║███████║██║     █████╔╝ \n"
                printf "██╔══██╗██╔══╝╚════╝██║╚██╔╝██║██╔══██║██║     ██║███╗██║██╔══██║██║     ██╔═██╗ \n"
                printf "██║  ██║███████╗    ██║ ╚═╝ ██║██║  ██║███████╗╚███╔███╔╝██║  ██║╚██████╗██║  ██╗\n"
                printf "╚═╝  ╚═╝╚══════╝    ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝\n"
                ;;
        esac
    fi
    printf '\033[0m'
    update_status
    echo ""
    echo "$version - $status_msg"
    printf '\033[0;31m'
    echo "================================================================="
    printf '\033[0m'
}

# Function to check hosts file reset state
# Becomes true in case of both hosts counts = 0
# And becomes also true in case of blocked entries in both module and system hosts equals the blacklist file
# AKA only blacklisted entries are active
is_default_hosts() {
    [ "$blocked_mod" -eq 0 ] && [ "$blocked_sys" -eq 0 ] \
    || { [ "$blocked_mod" -eq "$blacklist_count" ] && [ "$blocked_sys" -eq "$blacklist_count" ]; }
}

# Function to process hosts, maybe?
host_process() {
    local file="$1"
    # Exclude whitelist files
    echo "$file" | tr '[:upper:]' '[:lower:]' | grep -q "whitelist" && return 0
    # Unified filtration: remove comments, empty lines, trim whitespaces, handles windows-formatted hosts, collapses all multiple spaces/tabs into a single space and converts 127.0.0.1 to 0.0.0.0
    log_message "Filtering $file..."
    sed -i '/^[[:space:]]*#/d; s/[[:space:]]*#.*$//; /^[[:space:]]*$/d; s/^[[:space:]]*//; s/[[:space:]]*$//; s/\r$//; s/[[:space:]]\+/ /g; s/127.0.0.1/0.0.0.0/g' "$file"
}

# Function to apply custom rules
apply_custom_rules() {
    if [ -s "$persist_dir/custom_rules.txt" ]; then
        log_message "Re-Applying custom rules..."
        echo "[*] Re-Applying custom rules..."
        # Add a newline just in case
        [ -s "$hosts_file" ] && tail -c1 "$hosts_file" | grep -qv $'\n' && echo "" >> "$hosts_file"
        cat "$persist_dir/custom_rules.txt" >> "$hosts_file"
    fi
}

# Function to count blocked entries and store them
refresh_blocked_counts() {
    mkdir -p "$persist_dir/counts"
    log_message INFO "Refreshing blocked entries counts"
    blocked_mod=$(grep -c "0.0.0.0" $hosts_file || true)
    blocked_sys=$(grep -c "0.0.0.0" $system_hosts || true)
    echo "${blocked_sys:-0}" > "$persist_dir/counts/blocked_sys.count"
    echo "${blocked_mod:-0}" > "$persist_dir/counts/blocked_mod.count"
    log_message "Module hosts: $blocked_mod entries, System hosts: $blocked_sys entries"
}

# Functions for protection switch

# function to check adblock pause
is_protection_paused() {
    [ -f "$persist_dir/hosts.bak" ] || return 1
}

# 1 - Pause adblock
pause_protections() {
    # Check if protection is paused, enable if it is paused.
    if is_protection_paused; then
        resume_protections
        exit 0
    fi
    
    # Prevent pausing if hosts is reset
    if is_default_hosts && ! is_protection_paused; then
        abort "You cannot pause protections while hosts is reset."
    fi
    local start_time
    start_time=$(get_current_time)
    log_message "Pausing Protections"
    echo "[*] Pausing Protections"
    cp "$hosts_file" "$persist_dir/hosts.bak"
    printf "127.0.0.1 localhost\n::1 localhost\n" > "$hosts_file"
    sed -i 's/^adblock_switch=.*/adblock_switch=1/' "$persist_dir/config.sh"
    refresh_blocked_counts
    update_status
    log_message SUCCESS "Protection has been paused."
    local end_time
    end_time=$(get_current_time)
    log_duration "Pausing protections" "$start_time" "$end_time"
    echo "[✓] Protection has been paused."
}

# 2 - Resume adblock
resume_protections() {
    local start_time
    start_time=$(get_current_time)
    log_message "Resuming protection."
    echo "[*] Resuming protection"
    if [ -f "$persist_dir/hosts.bak" ]; then
        cat "$persist_dir/hosts.bak" > "$hosts_file"
        rm -f $persist_dir/hosts.bak
        sed -i 's/^adblock_switch=.*/adblock_switch=0/' "/data/adb/Re-Malwack/config.sh"
        refresh_blocked_counts
        update_status
        log_message SUCCESS "Protection has been resumed."
        local end_time
        end_time=$(get_current_time)
        log_duration "Resuming protections" "$start_time" "$end_time"
        echo "[✓] Protection has been resumed."
    else
        log_message WARN "No backup hosts file found to resume"
        log_message "Force resuming protection and running hosts update as a fallback action"
        echo "[!] No backup hosts file found to resume."
        sleep 0.5
        echo "[i] Force resuming protection and running hosts update as a fallback action"
        check_internet
        sleep 2
        sed -i 's/^adblock_switch=.*/adblock_switch=0/' "/data/adb/Re-Malwack/config.sh"
        exec "$0" --quiet --update-hosts
    fi
}

# Logging func - Literally helpful for any dev :D
log_message() {

    timestamp() {
        date +"%Y-%m-%d %I:%M:%S %p"
    }

    # Handle optional log level (default: INFO)
    case "$1" in
        INFO|WARN|ERROR|SUCCESS)
            level="$1"
            shift
            ;;
        *)
            level="INFO"
            ;;
    esac
    msg="$*"
    line="[$(timestamp)] - [$level] - $msg"
    echo "$line" >> "$LOGFILE"
}

# Function to get current time in milliseconds
get_current_time() {
    # Using date +%s%N for nanoseconds
    # Fallback to %s if %N is not supported
    time_ns=$(date +%s%N 2>/dev/null)
    if [ $? -ne 0 ] || [ "$time_ns" = "%s%N" ]; then
        # Fallback: use seconds only, return as milliseconds
        time_ms=$(($(date +%s) * 1000))
    else
        # Convert nanoseconds to milliseconds by dividing by 1,000,000
        time_ms=$((time_ns / 1000000))
    fi
    echo "$time_ms"
}

# Function to format duration from milliseconds to human-readable format
# Smart format: only shows non-zero units (e.g., "1m, 42s and 433ms" or "5s and 234ms")
format_duration() {
    local duration_ms=$1
    local minutes=$(( duration_ms / 60000 ))
    local remainder=$(( duration_ms % 60000 ))
    local seconds=$(( remainder / 1000 ))
    local milliseconds=$(( remainder % 1000 ))
    local parts=""

    # Add minutes if non-zero
    if [ "$minutes" -gt 0 ]; then
        if [ "$minutes" -eq 1 ]; then
            parts="1m"
        else
            parts="${minutes}m"
        fi
    fi

    # Add seconds if non-zero
    if [ "$seconds" -gt 0 ]; then
        if [ -z "$parts" ]; then
            if [ "$seconds" -eq 1 ]; then
                parts="1s"
            else
                parts="${seconds}s"
            fi
        else
            if [ "$seconds" -eq 1 ]; then
                parts="$parts, 1s"
            else
                parts="$parts, ${seconds}s"
            fi
        fi
    fi

    # Add milliseconds if non-zero or if both minutes and seconds are zero
    if [ "$milliseconds" -gt 0 ] || [ -z "$parts" ]; then
        if [ -z "$parts" ]; then
            if [ "$milliseconds" -eq 1 ]; then
                parts="1ms"
            else
                parts="${milliseconds}ms"
            fi
        else
            if [ "$milliseconds" -eq 1 ]; then
                parts="$parts and 1ms"
            else
                parts="$parts and ${milliseconds}ms"
            fi
        fi
    fi

    # Ensure at least milliseconds are shown
    if [ -z "$parts" ]; then
        parts="0ms"
    fi

    echo "$parts"
}

# Function to log job duration
log_duration() {
    local job_name="$1"
    local start_time="$2"
    local end_time="$3"

    # Calculate duration in milliseconds
    local duration_ms=$(( end_time - start_time ))

    # Handle negative duration (clock adjustment)
    if [ "$duration_ms" -lt 0 ]; then
        duration_ms=$(( -duration_ms ))
    fi

    # Format duration
    local formatted_time
    formatted_time=$(format_duration "$duration_ms")

    # Log the result
    log_message SUCCESS "Task [$job_name] took $formatted_time"
}

# Function to query domain status in hosts file
query_domain() {
    local domain="$1"

    if [ -z "$domain" ]; then
        echo "[!] No domain provided."
        echo "[i] Usage: rmlwk --query-domain <domain> or rmlwk -q <domain>"
        echo "[i] Example: rmlwk --query-domain example.com"
        exit 1
    fi

    # Sanitize input - extract domain from URL if needed
    if printf '%s' "$domain" | grep -qE '^https?://'; then
        domain=$(printf '%s' "$domain" | awk -F[/:] '{print $4}')
    fi

    # Validate domain format
    if ! printf '%s' "$domain" | grep -qiE '^[a-z0-9]([a-z0-9-]*\.)*[a-z0-9-]*[a-z0-9]$|^[a-z0-9]$'; then
        abort "Invalid domain format: $domain"
    fi

    log_message "Querying domain: $domain"

    # Search in hosts file for the domain
    # This will find lines like "0.0.0.0 example.com" or "127.0.0.1 example.com"
    entry=$(grep -E "^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|[0-9a-fA-F:]+)[[:space:]]+${domain}([[:space:]]|$)" "$hosts_file" 2>/dev/null | head -1)

    if [ -z "$entry" ]; then
        echo "[i] Domain '$domain' is NOT blocked"
        log_message "Domain query result: $domain is NOT blocked"
        return 0
    fi

    # Extract the IP address from the entry
    ip=$(echo "$entry" | awk '{print $1}')

    # Check if it's a blocking IP
    case "$ip" in
        0.0.0.0)
            echo "[!] Domain '$domain' IS BLOCKED"
            echo "[i] IP: $ip"
            log_message "Domain query result: $domain IS BLOCKED with IP $ip"
            return 0
            ;;
        *)
            # If it's a different IP, it's redirected
            echo "[⟳] Domain '$domain' IS REDIRECTED"
            echo "[i] Redirected to IP: $ip"
            log_message "Domain query result: $domain IS REDIRECTED to IP $ip"
            return 0
            ;;
    esac
}

# Function to export logs
export_logs() {
    log_message "Exporting logs..."
    VERSION=$(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2)
    LOG_DATE="$(date +%Y-%m-%d__%H%M%S)"

    if echo "$VERSION" | grep -q "\-test.*(.*@.*)"; then
        base_version=$(echo "$VERSION" | sed 's/-test.*//')
        build_id=$(echo "$VERSION" | sed 's/.*(\(.*\)).*/\1/' | sed 's/\//_/g')
        tarFileName="Re-Malwack_${base_version}-${build_id}_logs_${LOG_DATE}.tar.gz"
    else
        clean_version=$(echo "$VERSION" | sed 's/\//_/g')
        tarFileName="Re-Malwack_${clean_version}_logs_${LOG_DATE}.tar.gz"
    fi
    log_message SUCCESS "Logs are going to be saved in: /sdcard/Download/$tarFileName"
    tar -czf "/sdcard/Download/$tarFileName" -C "$persist_dir" logs
    echo "Log saved to: /sdcard/Download/$tarFileName"
}

# Functions to process hosts

# 1. Helper to stage cached blocklist files into tmp
stage_blocklist_files() {
    local block_type="$1"
    local i=1
    for file in "$persist_dir/cache/$block_type/hosts"*; do
        [ -f "$file" ] || continue
        cp -f "$file" "${tmp_hosts}${i}"
        i=$((i+1))
    done
}

# 2. Install hosts
install_hosts() {
    type="$1"
    local start_time
    start_time=$(get_current_time)
    log_message "Fetching module's repo whitelist files"
    # Update hosts for global whitelist
    mkdir -p "$persist_dir/cache/whitelist"
    fetch "$persist_dir/cache/whitelist/whitelist.txt" https://raw.githubusercontent.com/ZG089/Re-Malwack/main/whitelist.txt
    fetch "$persist_dir/cache/whitelist/social_whitelist.txt" https://raw.githubusercontent.com/ZG089/Re-Malwack/main/social_whitelist.txt
    log_message "Starting to install $type hosts."
    # Prepare original hosts
    cp -f "$hosts_file" "${tmp_hosts}0"
    # Process blacklist and merge into previous hosts
    log_message "Preparing Blacklist..."
    [ -s "$persist_dir/blacklist.txt" ] && awk 'NF && $1 !~ /^#/ { print "0.0.0.0", $1 }' "$persist_dir/blacklist.txt" >> "${tmp_hosts}0"

    # Process whitelist
    log_message "Processing Whitelist..."
    whitelist_file="$persist_dir/cache/whitelist/whitelist.txt"

    if [ "$block_social" -eq 0 ] && [ "$type" != "social" ]; then
        whitelist_file="$whitelist_file $persist_dir/cache/whitelist/social_whitelist.txt"
    else
        log_message WARN "Social Block triggered, Social whitelist won't be applied"
    fi

    # Append user-defined whitelist if it exists
    [ -s "$persist_dir/whitelist.txt" ] && whitelist_file="$whitelist_file $persist_dir/whitelist.txt"

    # Debugging - Check each whitelist file individually
    for file in $whitelist_file; do
        if [ ! -f "$file" ]; then
            log_message WARN "Whitelist file $file does not exist!"
        elif [ ! -s "$file" ]; then
            log_message WARN "Whitelist file $file is empty!"
        else
            log_message "Whitelist file $file found with content."
        fi
    done

    # Merge whitelist files into one
    cat $whitelist_file | sed '/#/d; /^$/d' | awk '{print "0.0.0.0", $0}' > "${tmp_hosts}w"

    # If whitelist is empty, log and skip filtering
    if [ ! -s "${tmp_hosts}w" ]; then
        log_message WARN "Whitelist is empty. Skipping whitelist filtering."
        echo "" > "${tmp_hosts}w"
    fi

    # In case of hosts update (since only combined file exists only on --update-hosts)
    if [ -f "$combined_file" ]; then
        log_message "Detected unified hosts, sorting..."
        cat "${tmp_hosts}0" >> "$combined_file"
        awk '!seen[$0]++' "$combined_file" > "${tmp_hosts}merged.sorted"
    else # In case of install_hosts() being called in block_content() or block_trackers()
        log_message "detected multiple hosts file, merging and sorting... (Blocklist toggles only)"
        LC_ALL=C sort -u "${tmp_hosts}"[!0] "${tmp_hosts}0" > "${tmp_hosts}merged.sorted"
    fi

    log_message "Filtering hosts"
    grep -Fvxf "${tmp_hosts}w" "${tmp_hosts}merged.sorted" > "$hosts_file" || {
        log_message WARN "Failed to filter with grep, trying awk fallback"
        # Fallback to awk if grep fails
        awk 'NR==FNR {seen[$0]=1; next} !seen[$0]' "${tmp_hosts}w" "${tmp_hosts}merged.sorted" > "$hosts_file"
    }
    apply_custom_rules

    # Clean up
    chmod 644 "$hosts_file"
    log_message "Cleaning up..."
    rm -f "${tmp_hosts}"* 2>/dev/null
    log_message SUCCESS "Successfully installed $type hosts."
    local end_time
    end_time=$(get_current_time)
    log_duration "Installing hosts (Type: $type)" "$start_time" "$end_time"
}

# 3. Remove hosts
remove_hosts() {
    local start_time
    start_time=$(get_current_time)
    log_message "Starting to remove hosts."
    # Prepare original hosts
    cp -f "$hosts_file" "${tmp_hosts}0"

    # Processing & sorting files
    cat "$cache_hosts"* | sort -u > "${tmp_hosts}1"

    # Remove from hosts file
    awk 'NR==FNR {seen[$0]=1; next} !seen[$0]' "${tmp_hosts}1" "${tmp_hosts}0" > "$hosts_file"

    # Restore to default entries if hosts file is empty
    if [ ! -s "$hosts_file" ]; then
        echo "[!] Hosts file is empty. Restoring default entries."
        log_message WARN "Detected empty hosts file"
        log_message "Restoring default entries..."
        echo -e "127.0.0.1 localhost\n::1 localhost" > "$hosts_file"
    fi

    # Clean up
    log_message "Cleaning up..."
    rm -f "${tmp_hosts}"* 2>/dev/null
    log_message SUCCESS "Successfully removed hosts."
    local end_time
    end_time=$(get_current_time)
    log_duration "Removing hosts" "$start_time" "$end_time"
}

# Function to block conte- bruhhh doesn't that seem to be clear to you already? -_-
block_content() {
    block_type=$1
    status=$2
    cache_hosts="$persist_dir/cache/$block_type/hosts"
    mkdir -p "$persist_dir/cache/$block_type"

    if [ "$status" = 0 ]; then
        if [ ! -f "${cache_hosts}1" ]; then
            log_message WARN "No cached $block_type blocklist found, redownloading to disable properly."
            echo "[!] No cached $block_type blocklist found, redownloading to disable properly"
            check_internet
            fetch_blocklist "$block_type"

            # Process downloaded hosts
            for file in "$persist_dir/cache/$block_type/hosts"*; do
                [ -f "$file" ] && host_process "$file"
            done

            # Stage cache to tmp then install
            stage_blocklist_files "$block_type"
            install_hosts "$block_type"
        fi
        remove_hosts
        sed -i "s/^block_${block_type}=.*/block_${block_type}=0/" "$persist_dir/config.sh"
        log_message SUCCESS "Disabled $block_type blocklist."
    else
        if [ ! -f "${cache_hosts}1" ] || [ "$status" = "update" ]; then
            check_internet
            echo "[*] Downloading hosts for $block_type block."
            fetch_blocklist "$block_type"
            # Process downloaded hosts
            for file in "$persist_dir/cache/$block_type/hosts"*; do
                [ -f "$file" ] && host_process "$file"
            done
        fi

        if [ "$status" != "update" ]; then
            stage_blocklist_files "$block_type"
            install_hosts "$block_type"
            sed -i "s/^block_${block_type}=.*/block_${block_type}=1/" "$persist_dir/config.sh"
            
            # Count the entries blocks for this blocklist
            bl_count=0
            for file in "$persist_dir/cache/$block_type/hosts"*; do
                if [ -f "$file" ]; then
                    file_count=$(wc -l < "$file")
                    bl_count=$((bl_count + file_count))
                fi
            done
            log_message SUCCESS "Enabled $block_type blocklist ($bl_count entries)."
        fi
    fi
}

# Function to remount hosts
remount_hosts() {
    if [ "$is_zn_detected" -eq 1 ]; then
        log_message "zn-hostsredirect detected, skipping mount operation"
        return 0
    fi
    log_message "Attempting to remount hosts..."
    log_message "system hosts file lines count: $system_hosts_lines, module hosts file lines count: $module_hosts_lines"
    echo "[*] Attempting to remount hosts..."
    umount -l "$system_hosts" 2>/dev/null || log_message WARN "Failed to unmount $system_hosts"
    mount --bind "$hosts_file" "$system_hosts" || {
        log_message ERROR "Failed to bind mount $hosts_file to $system_hosts"
        echo "[!] Failed to remount hosts, please report to developer!"
        return 1
    }
    log_message SUCCESS "Hosts remounted successfully."
    echo "[✓] Hosts remounted successfully."
}

# Function to block trackers
block_trackers() {
    local start_time
    start_time=$(get_current_time)
    status=$1
    cache_dir="$persist_dir/cache/trackers"
    cache_hosts="$cache_dir/hosts"
    mkdir -p "$cache_dir"
    brand=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')

    if [ "$status" = "disable" ] || [ "$status" = 0 ]; then
        if [ "$block_trackers" = 0 ]; then
            echo "[!] Trackers block is already disabled"
            return 0
        fi

        if ! ls "${cache_hosts}"* >/dev/null 2>&1; then
            check_internet
            log_message WARN "No cached trackers blocklist file found for $brand device, redownloading before removal."
            echo "[!] No cached trackers blocklist file(s) found for $brand device, redownloading before removal."
            fetch_blocklist "trackers"
            for file in "$persist_dir/cache/trackers/hosts"*; do
                [ -f "$file" ] && host_process "$file"
            done
            stage_blocklist_files "trackers"
            install_hosts "trackers"
        fi
        echo "[*] Disabling trackers block for $brand device"
        remove_hosts
        sed -i "s/^block_trackers=.*/block_trackers=0/" "$persist_dir/config.sh"
        log_message SUCCESS "Trackers blocklist disabled."
        local end_time
        end_time=$(get_current_time)
        log_duration "Disabling trackers block" "$start_time" "$end_time"
        echo "[✓] Trackers block has been disabled"
    else
        if [ "$block_trackers" = 1 ]; then
            echo "[!] Trackers block is already enabled"
            return 0
        fi

        if ! ls "${cache_hosts}"* >/dev/null 2>&1; then
            check_internet
            log_message "Fetching trackers block hosts for $brand"
            echo "[*] Fetching trackers block files for $brand"
            fetch_blocklist "trackers"
            host_process "${cache_hosts}1"
            host_process "${cache_hosts}2"
            # note to self
            # If we add a third general source for trackers
            # move cache_hosts3 to the general trackers blocklist fetching section
            # and change 3 to 4 below
            [ -f "${cache_hosts}3" ] && host_process "${cache_hosts}3"
        fi
        log_message "Enabling trackers block"
        echo "[*] Enabling trackers block for $brand"
        stage_blocklist_files "trackers"
        install_hosts "trackers"
        sed -i "s/^block_trackers=.*/block_trackers=1/" "$persist_dir/config.sh"
        
        # Count trackers entries
        tr_count=0
        for file in "$persist_dir/cache/trackers/hosts"*; do
            if [ -f "$file" ]; then
                file_count=$(wc -l < "$file")
                tr_count=$((tr_count + file_count))
            fi
        done
        log_message SUCCESS "Trackers blocklist enabled ($tr_count entries)."
        local end_time
        end_time=$(get_current_time)
        log_duration "Enabling trackers block" "$start_time" "$end_time"
        echo "[✓] Trackers block has been enabled"
    fi
}

fetch_blocklist() {
    bl="$1"
    cache_hosts="$persist_dir/cache/$bl/hosts"

    case "$bl" in
        porn)
            fetch "${cache_hosts}1" "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn-only/hosts"
            fetch "${cache_hosts}2" "https://raw.githubusercontent.com/4skinSkywalker/Anti-Porn-HOSTS-File/refs/heads/master/HOSTS.txt"
            ;;
        gambling)
            fetch "${cache_hosts}1" "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/gambling-only/hosts"
            fetch "${cache_hosts}2" "https://blocklistproject.github.io/Lists/gambling.txt"
            ;;
        fakenews|social)
            fetch "${cache_hosts}1" \
                "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/${bl}-only/hosts"
            ;;
        trackers)
            fetch "${cache_hosts}1" "https://raw.githubusercontent.com/r-a-y/mobile-hosts/refs/heads/master/AdguardTracking.txt"
            fetch "${cache_hosts}2" "https://blocklistproject.github.io/Lists/tracking.txt"

            # Device-specific tracker hosts
            brand=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]')
            case "$brand" in
                xiaomi|redmi|poco) url="https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/native.xiaomi.txt" ;;
                samsung)           url="https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/native.samsung.txt" ;;
                oppo|realme)       url="https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/native.oppo-realme.txt" ;;
                vivo)              url="https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/native.vivo.txt" ;;
                huawei)            url="https://raw.githubusercontent.com/hagezi/dns-blocklists/main/hosts/native.huawei.txt" ;;
                *) url="" ;;
            esac
            [ -n "$url" ] && fetch "${cache_hosts}3" "$url"
            ;;
        safebrowsing)
            fetch "${cache_hosts}1" "https://raw.githubusercontent.com/columndeeply/hosts/refs/heads/main/safebrowsing"
            ;;
    esac
    wait
}

# shortcase
tolower() {
    echo "$1" | tr '[:upper:]' '[:lower:]'
}

# uhhhhh
abort() {
    log_message "Aborting: $1"
    echo "[✗] $1"
    sleep 0.5
    exit 1
}

# Bruh It's clear already what this function does ._.
check_internet() {
    retry_count=0
    max_retries=6
    while ! ping -c 1 8.8.8.8 &>/dev/null; do
        retry_count=$((retry_count + 1))
        if [ "$retry_count" -ge "$max_retries" ]; then
            abort "No internet connection detected after $max_retries attempts, aborting..."
        fi
        log_message WARN "No internet connection detected, retrying... (Attempt $retry_count/$max_retries)"
        echo "[i] No internet connection detected, attempting to reconnect... (Attempt $retry_count/$max_retries)"
        sleep 1.5
    done
}

# Fetches hosts from sources.txt
# tmp_hosts 0 = This is the original hosts file, to prevent overwriting before cat process complete, ensure coexisting of different block type.
# tmp_hosts 1-9 = This is the downloaded hosts, to simplify process of install and remove function.
fetch() {
    local start_time
    start_time=$(get_current_time)
    local output_file="$1"
    local url="$2"
    PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
    # Curly hairyyy- *ahem*
    # So uhh, we check for curl existence, if it exists then we gotta use it to fetch hosts
    if command -v curl >/dev/null 2>&1; then
        dl_tool=curl
        if ! curl -Ls "$url" > "$output_file"; then
            log_message ERROR "Failed to download from $url with curl"
            echo "[!] Failed to download from $url"
            echo "" > "$output_file"
            return 1
        fi
    else # Else we gotta just fallback to windows ge- my bad I mean winget- BRUH it's wget :sob:
        dl_tool=wget
        if ! busybox wget --no-check-certificate -qO - "$url" > "$output_file"; then
            log_message ERROR "Failed to download from $url with wget"
            echo "[!] Failed to download from $url"
            echo "" > "$output_file"
            return 1
        fi
    fi
    log_message SUCCESS "Downloaded from $url using $dl_tool, stored in $output_file"
    local end_time
    end_time=$(get_current_time)
    log_duration "Fetching process" "$start_time" "$end_time"
}

# Updates module status, modifying module description in module.prop
update_status() {
    local start_time
    start_time=$(get_current_time)
    status_msg=""  # Reset status message
    . "$persist_dir/config.sh" # Sourcing config file
    log_message SUCCESS "loaded config file!"
    log_message "Selected profile: $profile"
    log_message INFO "Updating module status"
    log_message "Fetching last hosts file update"
    last_mod=$(stat -c '%y' "$hosts_file" 2>/dev/null | cut -d'.' -f1) # Checks last modification date for hosts file
    log_message "Last hosts file update was in: $last_mod"

    # System hosts count
    [ ! -d "/data/adb/modules/Re-Malwack" ] && log_message "First install detected (module directory missing)."

    # Module hosts count
    blocked_sys=$(cat "$persist_dir/counts/blocked_sys.count" 2>/dev/null)
    blocked_mod=$(cat "$persist_dir/counts/blocked_mod.count" 2>/dev/null)

    # Count blacklisted entries (excluding comments and empty lines)
    [ -s "$persist_dir/blacklist.txt" ] && blacklist_count=$(grep -c '^[^#[:space:]]' "$persist_dir/blacklist.txt") || blacklist_count=0

    # Count whitelisted entries (excluding comments and empty lines)
    [ -s "$persist_dir/whitelist.txt" ] && whitelist_count=$(grep -c '^[^#[:space:]]' "$persist_dir/whitelist.txt") || whitelist_count=0
    log_message "Blacklist entries count: $blacklist_count"
    log_message "Whitelist entries count: $whitelist_count"

    # Determine mode based on zn-hostsredirect detection
    if [ "$is_zn_detected" -eq 1 ]; then
        mode="hosts mount mode: zn-hostsredirect"
    else
        mode="hosts mount mode: Standard mount"
    fi

    # Log enabled blocklists
    enabled_blocklists=""
    for bl in porn gambling fakenews social trackers safebrowsing; do
        eval enabled=\$block_${bl}
        if [ "$enabled" = "1" ]; then
            if [ -z "$enabled_blocklists" ]; then
                enabled_blocklists=" $bl"
            else
                enabled_blocklists="$enabled_blocklists - $bl"
            fi
        fi
    done
    if [ -n "$enabled_blocklists" ]; then
        log_message INFO "Enabled blocklists:$enabled_blocklists"
    else
        log_message INFO "No blocklists enabled"
    fi

    # Here goes the part where we actually determine module status
    if [ -f "$persist_dir/mode_ready" ] && [ "$blocked_mod" -gt 0 ]; then
        # Clear mode_ready flag if hosts file has blocked entries
        rm -f "$persist_dir/mode_ready"
        log_message "Cleared mode_ready flag, hosts file has $blocked_mod blocked entries"
    fi

    if [ -f "$persist_dir/mode_ready" ]; then
        [ -z "$profile" ] && profile="default"
        status_msg="Status: Protection is idle 💤 | ⚙️ Profile: $profile"
    elif is_protection_paused; then
        [ -z "$profile" ] && profile="default"
        status_msg="Status: Protection is paused ⏸️ | ⚙️ Profile: $profile"
    elif [ -d /data/adb/modules_update/Re-Malwack ]; then
        [ -z "$profile" ] && profile="default"
        status_msg="Status: Reboot required to apply changes 🔃 (pending module update) | ⚙️ Profile: $profile"
    elif [ -d /data/adb/modules_update/Re-Malwack ] && [ ! -d /data/adb/modules/Re-Malwack ]; then
        [ -z "$profile" ] && profile="default"
        status_msg="Status: Reboot required to apply changes 🔃 (First time install) | ⚙️ Profile: $profile"
    elif is_default_hosts; then
        [ -z "$profile" ] && profile="default"
        if [ "$blacklist_count" -gt 0 ]; then
            plural="entries are active"
            [ "$blacklist_count" -eq 1 ] && plural="entry is active"
            status_msg="Status: Protection is disabled due to reset ❌ | ⚙️ Profile: $profile | $blacklist_count blacklist $plural"
        else
            status_msg="Status: Protection is disabled due to reset ❌ | ⚙️ Profile: $profile"
        fi
    elif [ "$blocked_mod" -ge 0 ]; then
        system_hosts_lines=$(cat "$system_hosts" 2>/dev/null | wc -l)
        module_hosts_lines=$(cat "$hosts_file" 2>/dev/null | wc -l)
        if [ "$module_hosts_lines" -ne "$system_hosts_lines" ] && [ "$is_zn_detected" -ne 1 ]; then
            # Attempt to remount hosts and refresh status
            # Only in case of broken mount detection
            remount_hosts
            refresh_blocked_counts
            system_hosts_lines=$(cat "$system_hosts" 2>/dev/null | wc -l)
            module_hosts_lines=$(cat "$hosts_file" 2>/dev/null | wc -l)
            if [ "$module_hosts_lines" -ne "$system_hosts_lines" ]; then
                status_msg="Status: ❌ Critical Error Detected (Hosts Mount Failure). Please check your root manager settings and disable any conflicted module(s)."
                echo "[!!!] Critical Error Detected (Hosts Mount Failure). Please check your root manager settings and disable any conflicted module(s)."
                echo "[!!!] Module hosts blocks $blocked_mod domains, System hosts blocks $blocked_sys domains."
            fi
        fi
        # Set success message if not set to error
        if [ -z "$status_msg" ]; then
            [ -z "$profile" ] && profile="default"
            if [ "$(date +%m%d)" = "0401" ]; then
                blocking_info="Allowing $blocked_mod ads"
                [ "$blacklist_count" -gt 0 ] && blocking_info="Allowing $((blocked_mod - blacklist_count)) ads + $blacklist_count (blacklist)"
                status_msg="Status: Protection is Vulnerable ✅ | ⚙️ Profile: $profile | $blocking_info"
                [ "$whitelist_count" -gt 0 ] && status_msg="$status_msg | Whitelist: $whitelist_count"
                [ -n "$enabled_blocklists" ] && status_msg="$status_msg | Enabled Allowlists:$enabled_blocklists"

                sed -i 's/^name=.*/name=Re-Malware | Not just a normal malware module ✨/' "$MODDIR/module.prop"
                sed -i 's/^banner=.*/banner=banner_alt.png/' "$MODDIR/module.prop"
            else
                blocking_info="Blocking $blocked_mod domains"
                [ "$blacklist_count" -gt 0 ] && blocking_info="Blocking $((blocked_mod - blacklist_count)) domains + $blacklist_count (blacklist)"
                status_msg="Status: Protection is enabled ✅ | ⚙️ Profile: $profile | $blocking_info"
                [ "$whitelist_count" -gt 0 ] && status_msg="$status_msg | Whitelist: $whitelist_count"
                [ -n "$enabled_blocklists" ] && status_msg="$status_msg | Enabled Blocklists:$enabled_blocklists"

                sed -i 's/^name=.*/name=Re-Malwack | Not just a normal ad-blocker module ✨/' "$MODDIR/module.prop"
                sed -i 's/^banner=.*/banner=banner.png/' "$MODDIR/module.prop"
            fi
        fi
    fi

    # Update module description
    sed -i "s/^description=.*/description=$status_msg/" "$MODDIR/module.prop"
    log_message "$status_msg"
    local end_time
    end_time=$(get_current_time)
    log_duration "Updating module status" "$start_time" "$end_time"
}

# Functions for auto-update (cron jobs)

# 1 - Detect cron provider
detect_cron_provider() {
    if command -v busybox >/dev/null 2>&1 && busybox crond --help >/dev/null 2>&1; then
        echo busybox
    elif command -v toybox >/dev/null 2>&1 && toybox crond --help >/dev/null 2>&1; then
        echo toybox
    else
        return 1
    fi
}

# 1.2 - Helper function for applets usage
cron_cmd() {
    case "$CRON_PROVIDER" in
        busybox) echo "busybox $1" ;;
        toybox)  echo "toybox $1" ;;
    esac
}

# 2 - Fallback auto update script
auto_update_fallback() {
    FALLBACK_SCRIPT="$persist_dir/auto_update_fallback.sh"
    cat > "$FALLBACK_SCRIPT" << 'EOF'
#!/system/bin/sh
LOGFILE="/data/adb/Re-Malwack/logs/auto_update-fallback.log"
PID=$$
echo $PID > /data/adb/Re-Malwack/logs/auto_update.pid
echo "[$(date '+%Y-%m-%d %H:%M:%S')] - Fallback auto update script started with PID $PID" >> "$LOGFILE" 2>&1
while true; do
    sleep 86400 # Sleep for 24 hours
    {
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] - Auto-update check started"
        if sh /data/adb/modules/Re-Malwack/rmlwk.sh --update-hosts --quiet 2>&1; then
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] - Auto update completed successfully"
        else
            echo "[$(date '+%Y-%m-%d %H:%M:%S')] - Auto update failed"
        fi
    } >> "$LOGFILE" 2>&1
done
EOF
    # Make the fallback script executable and run it in the background
    chmod +x "$FALLBACK_SCRIPT"
    nohup "$FALLBACK_SCRIPT" >/dev/null 2>&1 &
    sleep 1

    # Verify if the fallback script is running
    if ! kill -0 "$(cat $persist_dir/logs/auto_update.pid 2>/dev/null)" 2>/dev/null; then
        echo "[!] Failed to start fallback auto update script, We're officially cooked twin 🥀"
        log_message ERROR "Fallback auto update script failed to stay alive"
        rm -f "$FALLBACK_SCRIPT"
        exit 1
    fi

}

# 3 - Enable auto update
enable_auto_update() {
    JOB_DIR="$persist_dir/auto_update"
    JOB_FILE="$JOB_DIR/root"
    CRON_JOB="0 */12 * * * ( sh /data/adb/modules/Re-Malwack/rmlwk.sh --update-hosts --quiet 2>&1 || echo \"Auto-update failed at \$(date)\" ) >> /data/adb/Re-Malwack/logs/auto_update-cron.log"
    PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
    local start_time
    start_time=$(get_current_time)

    log_message "Enabling auto update has been initiated."

    if [ "$daily_update" = "1" ]; then
        abort "Auto update is already enabled"
        return
    fi

    if CRON_PROVIDER=$(detect_cron_provider); then
        CROND=$(cron_cmd crond)
        CRONTAB=$(cron_cmd crontab)

        echo "[*] Enabling auto update via cron."
        log_message "Enabling auto update via cron, Using $CRON_PROVIDER as cron provider."

        mkdir -p "$JOB_DIR" "$persist_dir/logs"
        echo "$CRON_JOB" > "$JOB_FILE"
        $CRONTAB "$JOB_FILE" -c "$JOB_DIR"
        log_message SUCCESS "Cron job added, running crond..."
        $CROND -b -c "$JOB_DIR" -L "$persist_dir/logs/auto_update-cron.log"
        log_message SUCCESS "Started crond successfully."
        sleep 1.5 # Give crond some time to start and register the job
        CROND_PID="$(busybox pgrep -f "crond.*$JOB_DIR" | head -n 1 || true)"

        if [ -n "$CROND_PID" ]; then
            log_message SUCCESS "crond started! (PID:$CROND_PID)"
        else
            log_message WARN "crond process was not found, falling back to script loop method."
            echo "[!] Crond failed to run in the background, falling back to script loop method."
            rm -rf "$JOB_DIR"
            auto_update_fallback
            log_message SUCCESS "Fallback auto update script started."
        fi
    else
        echo "[i] No cron provider detected, falling back to script loop method."
        log_message WARN "No cron provider detected, falling back to script loop method."
        auto_update_fallback
        log_message SUCCESS "Fallback auto update script started."
    fi

    sed -i 's/^daily_update=.*/daily_update=1/' "/data/adb/Re-Malwack/config.sh"
    log_message SUCCESS "Auto update has been enabled."
    local end_time
    end_time=$(get_current_time)
    log_duration "Enabling auto update" "$start_time" "$end_time"
    echo "[✓] Auto update has been enabled."
}

# 4 - Disable auto update
disable_auto_update() {
    JOB_DIR="$persist_dir/auto_update"
    FALLBACK_SCRIPT="$persist_dir/auto_update_fallback.sh"
    PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
    local start_time
    start_time=$(get_current_time)

    if [ "$daily_update" = "0" ]; then
        abort "Auto update is already disabled"
        return
    fi

    log_message "Disabling auto update has been initiated."
    echo "[*] Disabling auto hosts update"

    if CRON_PROVIDER=$(detect_cron_provider); then
        KILL=$(cron_cmd kill)
        PIDOF=$(cron_cmd pidof)

        log_message "Killing cron processes, Using $CRON_PROVIDER applets."

        for pid in $($PIDOF crond 2>/dev/null); do
            $KILL -9 "$pid" >/dev/null 2>&1
        done

        rm -rf "$JOB_DIR"
        log_message "Cron job removed."
    else
        # Stop fallback loop if cron was never used
        log_message "Killing fallback auto update script."
        PID="$(cat "$persist_dir/logs/auto_update.pid" 2>/dev/null)"
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            kill -9 "$PID" >/dev/null 2>&1
            log_message SUCCESS "Fallback auto update script stopped (PID:$PID)"
        fi
        rm -f "$FALLBACK_SCRIPT"
        log_message "Fallback auto update script stopped and removed."
    fi

    sed -i 's/^daily_update=.*/daily_update=0/' "/data/adb/Re-Malwack/config.sh"
    local end_time
    end_time=$(get_current_time)
    log_message SUCCESS "Auto update has been disabled."
    log_duration "Disabling auto update" "$start_time" "$end_time"
    echo "[✓] Auto update has been disabled."
}

# ===== Pre-main logic =====

# 1 - log module version
log_message "Running Re-Malwack version $version"

# 2 - Check if zygisk host redirect module is enabled
if [ -d "$zn_module_dir" ] && [ ! -f "$zn_module_dir/disable" ] && [ ! -f "$zn_module_dir/remove" ]; then
    is_zn_detected=1
    hosts_file="/data/adb/hostsredirect/hosts"
    log_message "Zygisk host redirect module detected, using /data/adb/hostsredirect/hosts as target hosts file"
else
    hosts_file="$MODDIR/system/etc/hosts"
    log_message "Using standard mount method with $MODDIR/system/etc/hosts"
fi

# 3 - Trigger force stats refresh on WebUI
if [ "$WEBUI" = "true" ]; then
    refresh_blocked_counts
    update_status
fi
# 4 - Error logging lore

# 4.1 - Log errors
exec 2>>"$LOGFILE"

# 4.2 - Trap errors (logs failing command line no. + exit code)
set -e
trap '
exit_code=$?
timestamp=$(date +"%Y-%m-%d %I:%M:%S %p")

case $exit_code in
    0)   msg="Script ran successfully ✅ - No errors" ;;
    1)   msg="General error at line $LINENO ❌" ;;
    126) msg="Command at line $LINENO invoked cannot execute ❌" ;;
    127) msg="Command at line $LINENO not found ❌" ;;
    137) msg="Killed (SIGKILL / OOM) ❌" ;;
    *)   msg="Unknown error at line $LINENO ❌ (code $exit_code)" ;;
esac

echo "[$timestamp] - [$msg]" >> "$LOGFILE"
' EXIT

# 5 - Check for --quiet argument
for arg in "$@"; do
    if [ "$arg" = "--quiet" ]; then
        quiet_mode=1
        break
    fi
done

# 6 - Show banner if not running from Magisk Manager / quiet mode is disabled
[ -z "$MAGISKTMP" ] && [ "$quiet_mode" = 0 ] && rmlwk_banner

log_message INFO "========== End of pre-main logic =========="

# ====== Main Logic ======
case "$(tolower "$1")" in
    --profile|-p)
        profile_name="$2"
        if [ -z "$profile_name" ] || { [ ! -f "$MODDIR/profiles/${profile_name}.txt" ] && [ "$profile_name" != "custom" ]; }; then
            echo "[!] Invalid profile or missing argument."
            echo "[i] Available profiles: default, lite, balanced, aggressive, custom"
            exit 1
        fi

        if [ "$profile_name" = "custom" ]; then
            sed -i 's/^profile=.*/profile=custom/' "$persist_dir/config.sh"
        else
            cp -f "$MODDIR/profiles/${profile_name}.txt" "$persist_dir/sources.txt"
            sed -i "s/^profile=.*/profile=$profile_name/" "$persist_dir/config.sh"
        fi
        log_message SUCCESS "Profile switched to $profile_name."
        echo "[✓] Profile switched to $profile_name. Please update hosts to apply changes."
        update_status
        ;;
    --adblock-switch|-as)
        pause_protections
        ;;
    --reset|-r)
        start_time=$(get_current_time)
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."
        is_default_hosts && abort "Hosts has been already reset."
        log_message "Resetting hosts command triggered, resetting..."
        echo "[*] Reverting the changes..."
        printf "127.0.0.1 localhost\n::1 localhost" > "$hosts_file"

        # Re-add blacklist entries after reset if they exist
        if [ -s "$persist_dir/blacklist.txt" ]; then
            echo "[*] Reinserting blacklist entries after reset..."
            grep -vFxf "$persist_dir/blacklist.txt" "$hosts_file" > "${tmp_hosts}_b"
            while read -r line; do
                echo "0.0.0.0 $line"
            done < "$persist_dir/blacklist.txt" >> "${tmp_hosts}_b"
            cat "${tmp_hosts}_b" > "$hosts_file"
            rm -f "${tmp_hosts}_b"
        fi
        apply_custom_rules
        chmod 644 "$hosts_file"

        # Reset blocklist values to 0
        sed -i 's/^block_\(.*\)=.*/block_\1=0/' "$persist_dir/config.sh"
        ndc resolver clearnetdns 2>/dev/null
        ndc resolver flushdefaultif 2>/dev/null
        refresh_blocked_counts
        update_status
        log_message SUCCESS "Successfully reset hosts."
        end_time=$(get_current_time)
        log_duration "Resetting hosts" "$start_time" "$end_time"
	    echo "[✓] Successfully reverted hosts."
        ;;
    --export-logs|-e)
        export_logs
        ;;
    --query-domain|-q)
        start_time=$(get_current_time)
        domain="$2"
        query_domain "$domain"
        end_time=$(get_current_time)
        log_duration "Querying domain: $domain" "$start_time" "$end_time"
        ;;
    --block-porn|-bp|--block-gambling|-bg|--block-fakenews|-bf|--block-social|-bs|--block-trackers|-bt|--block-safebrowsing|-bsb)
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."
        start_time=$(get_current_time)
        case "$1" in
            --block-porn|-bp) block_type="porn" ;;
            --block-gambling|-bg) block_type="gambling" ;;
            --block-fakenews|-bf) block_type="fakenews" ;;
            --block-social|-bs) block_type="social" ;;
            --block-trackers|-bt) block_type="trackers" ;;
            --block-safebrowsing|-bsb) block_type="safebrowsing" ;;
        esac
        status="$2"
        if [ "$block_type" = "trackers" ]; then
            # Handle trackers with its own function
            block_trackers "$status"
        else
            eval "block_toggle=\"\$block_${block_type}\""

            if [ "$status" = "disable" ] || [ "$status" = 0 ]; then
                if [ "$block_toggle" = 0 ]; then
                    echo "[i] $block_type block is already disabled"
                    exit 0
                else
                    log_message "Disabling ${block_type} blocklist has been initiated."
                    echo "[*] Disabling ${block_type} blocklist has been initiated."
                    block_content "$block_type" 0
                    log_message SUCCESS "Disabled ${block_type} blocklist successfully."
                    echo "[✓] Disabled ${block_type} blocklist successfully."
                fi
            else
                if [ "$block_toggle" = 1 ]; then
                    echo "[!] ${block_type} block is already enabled"
                    exit 0
                else
                    log_message "Enabling block entries for $block_type has been initiated."
                    echo "[*] Enabling block entries for ${block_type} has been initiated."
                    block_content "$block_type" 1
                    log_message SUCCESS "Enabled ${block_type} blocklist successfully."
                    echo "[✓] Enabled ${block_type} blocklist successfully."
                fi
            fi
        fi
        refresh_blocked_counts
        update_status
        end_time=$(get_current_time)
        log_duration "Toggling ${block_type} blocklist" "$start_time" "$end_time"
        ;;

    --whitelist|-w)
        start_time=$(get_current_time)
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."
        is_default_hosts && abort "You cannot whitelist links while hosts is reset."
        action="$2"
        raw_input="$3"
        if [ -z "$action" ] || [ -z "$raw_input" ] || { [ "$action" != "add" ] && [ "$action" != "remove" ]; }; then
            echo "[!] Invalid arguments for --whitelist|-w"
            echo "[i] Usage: rmlwk --whitelist|-w <add|remove> [domain2] [domain3] ..."
            echo "[i] Examples:"
            echo "  rmlwk -w add example.com           # Add domain to the whitelist"
            echo "  rmlwk --whitelist add *.example.com # Add subdomain wildcard to whitelist"
            echo "  rmlwk -w add *something            # Add suffix wildcard to whitelist"
            echo "  rmlwk --whitelist add something*   # Add prefix wildcard to whitelist"
            echo "  rmlwk --whitelist remove example.com # Remove domain from whitelist"
            echo "  rmlwk -w remove domain1.com domain2.com domain3.com # Remove multiple domains from whitelist"
            display_whitelist=$(cat "$persist_dir/whitelist.txt" 2>/dev/null || true )
            [ -n "$display_whitelist" ] && echo -e "Current whitelist:\n$display_whitelist" || echo "Current whitelist: no saved whitelist"
            exit 1
        fi

        # Extract host if a URL was passed
        if printf '%s' "$raw_input" | grep -qE '^https?://'; then
            host=$(printf '%s' "$raw_input" | awk -F[/:] '{print $4}')
        else
            host="$raw_input"
        fi

        # Validate domain format (Special cases for wildcards)
        if ! printf '%s' "$host" | grep -qE '(\*|\.)'; then
            echo "[!] Invalid domain input: $raw_input"
            echo "[i] Valid domain input examples: 'domain.com', '*.domain.com', '*something', 'something*'"
            exit 1
        fi

        # Ensure the domain is not already blacklisted
        if grep -Fxq "$host" "$persist_dir/blacklist.txt"; then
            echo "[!] Cannot whitelist $raw_input, it already exists in blacklist."
            exit 1
        fi

        # Determine wildcard mode
        # - suffix wildcard if starts with "*.something" or ".something"
        # - glob mode if contains '*' anywhere (over entire domain)
        suffix_wildcard=0
        glob_mode=0
        if printf '%s' "$host" | grep -qE '^\*\.|^\.'; then
            suffix_wildcard=1
        elif printf '%s' "$host" | grep -q '\*'; then
            glob_mode=1
        fi

        # Normalize the base domain/pattern
        base="$host"
        if [ "$suffix_wildcard" -eq 1 ]; then
            # strip leading "*." or "." (one label or the dot)
            base="${base#*.}"
        fi

        # Build a domain-only ERE for matching the 2nd field in hosts
        # 1) escape regex metachars except '*' (handled separately for glob mode)
        esc_base=$(printf '%s' "$base" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')

        if [ "$suffix_wildcard" -eq 1 ]; then
            # match example.com or any subdomain of it
            dom_re="(^|.*\.)${esc_base}$"
        elif [ "$glob_mode" -eq 1 ]; then
            # treat '*' as glob over the whole domain
            esc_glob=$(printf '%s' "$esc_base" | sed 's/\*/.*/g')
            dom_re="^${esc_glob}$"
        else
            # exact domain
            dom_re="^${esc_base}$"
        fi
        # Prepare whitelist file
        touch "$persist_dir/whitelist.txt"
        if [ "$action" = "add" ]; then
            # Detect input type
            case "$raw_input" in
                \*\.*) # Subdomain: *.domain.com
                    domain="${raw_input#*.}"
                    esc_domain=$(printf '%s' "$domain" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')
                    pattern="^0\.0\.0\.0 [^.]+\\.${esc_domain}\$"
                    match_type="subdomain"
                    ;;
                \**) # Suffix: *something
                    suffix="${raw_input#\*}"
                    esc_suffix=$(printf '%s' "$suffix" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')
                    pattern="^0\.0\.0\.0 .*${esc_suffix}\$"
                    match_type="suffix"
                    ;;
                *\*) # Prefix: something*
                    prefix="${raw_input%\*}"
                    esc_prefix=$(printf '%s' "$prefix" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')
                    pattern="^0\.0\.0\.0 ${esc_prefix}.*\$"
                    match_type="prefix"
                    ;;
                *) # Exact
                    domain="$raw_input"
                    esc_domain=$(printf '%s' "$domain" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')
                    pattern="^0\.0\.0\.0 ${esc_domain}\$"
                    match_type="exact"
                    ;;
            esac

            # Ensure whitelist file exists
            touch "$persist_dir/whitelist.txt"

            # Check if already whitelisted
            if grep -qxF "$raw_input" "$persist_dir/whitelist.txt"; then
                echo "[i] $raw_input is already whitelisted"
                exit 1
            fi

            # Collect matches
            matched_domains=$(grep -E "$pattern" "$hosts_file" | awk '{print $2}' | sort -u)
            if [ -z "$matched_domains" ]; then
                echo "[!] No matches found for $raw_input"
                exit 1
            fi

            # Remove blacklisted entries from the match set
            if [ -s "$persist_dir/blacklist.txt" ]; then
                matched_domains=$(printf '%s\n' "$matched_domains" | grep -Fvxf "$persist_dir/blacklist.txt")
            fi

            # If nothing left, bail out
            # This code may be removed in the future?
            # I only wrote it just in case a very rare chance that all matched domains are blacklisted
            # Like, someone tries to whitelist the whole blacklisted domains list in one wildcard :sob:
            # idk who's going to do such a thing like this, but uhmmmmmm
            if [ -z "$matched_domains" ]; then
                echo "[!] All matched domains are already blacklisted, nothing to whitelist."
                exit 1
            fi

            # Add matched domains to whitelist file
            log_message "Whitelisting ($match_type): $raw_input. Domains: $matched_domains"
            echo "[*] Whitelisting ($match_type): $raw_input"
            for md in $matched_domains; do
                if ! grep -qxF "$md" "$persist_dir/whitelist.txt"; then
                    echo "$md" >> "$persist_dir/whitelist.txt"
                fi
            done

            # Rewrite hosts file excluding matched domains
            tmp_hosts="$persist_dir/tmp.hosts.$$"
            grep -Ev "$pattern" "$hosts_file" > "$tmp_hosts"
            cat "$tmp_hosts" > "$hosts_file"
            rm -f "$tmp_hosts"

            # Deduplicate whitelist file
            tmpf="$persist_dir/.whitelist.sorted.$$"
            sort -u "$persist_dir/whitelist.txt" > "$tmpf" && mv "$tmpf" "$persist_dir/whitelist.txt"

            # Finalize
            echo "[✓] Whitelisted ($match_type): $raw_input"
            echo "[i] Added the following domain(s) to whitelist and removed from hosts:"
            printf " - %s\n" $matched_domains
            log_message SUCCESS "Whitelisted $raw_input ($match_type)."
            refresh_blocked_counts
            update_status
            end_time=$(get_current_time)
            log_duration "Adding to whitelist: $raw_input (type: $match_type)" "$start_time" "$end_time"
        else  # remove
            shift 2  # move past: --whitelist remove
            if [ $# -lt 1 ]; then
                echo "[!] No domains/patterns provided to remove."
                exit 1
            fi

            removed_total=""
            for raw in "$@"; do
                # Extract host (strip protocol if URL)
                if printf '%s' "$raw" | grep -qE '^https?://'; then
                    host=$(printf '%s' "$raw" | awk -F[/:] '{print $4}')
                else
                    host="$raw"
                fi

                # Skip invalid inputs quickly
                if [ -z "$host" ]; then
                    echo "[!] Invalid input: $raw"
                    continue
                fi

                # Determine pattern → build regex exactly like ADD mode
                suffix_wildcard=0
                glob_mode=0
                if printf '%s' "$host" | grep -qE '^\*\.|^\.'; then
                    suffix_wildcard=1
                elif printf '%s' "$host" | grep -q '\*'; then
                    glob_mode=1
                fi

                base="$host"
                [ "$suffix_wildcard" -eq 1 ] && base="${base#*.}"

                esc_base=$(printf '%s' "$base" | sed -e 's/[.[\^$+?(){}|\\]/\\&/g')

                if [ "$suffix_wildcard" -eq 1 ]; then
                    dom_re="(^|.*\.)${esc_base}$"
                elif [ "$glob_mode" -eq 1 ]; then
                    esc_glob=$(printf '%s' "$esc_base" | sed 's/\*/.*/g')
                    dom_re="^${esc_glob}$"
                else
                    dom_re="^${esc_base}$"
                fi

                # Find matches inside whitelist
                matches=$(grep -E "$dom_re" "$persist_dir/whitelist.txt" || true)
                if [ -z "$matches" ]; then
                    echo "[i] No whitelist matches for: $raw"
                    continue
                fi

                echo "[*] Removing from whitelist: $raw"
                removed_total="$removed_total $matches"

                # Remove from whitelist
                tmpf="$persist_dir/.whitelist.$$"
                grep -Ev "$dom_re" "$persist_dir/whitelist.txt" > "$tmpf" || true
                mv "$tmpf" "$persist_dir/whitelist.txt"
            done

            if [ -z "$removed_total" ]; then
                echo "[!] Nothing was removed from whitelist."
                exit 1
            fi

            # Re-block once at the end
            for dom in $removed_total; do
                if ! grep -qE "^0\.0\.0\.0[[:space:]]+$dom\$" "$hosts_file"; then
                    echo "0.0.0.0 $dom" >> "$hosts_file"
                fi
            done
            log_message SUCCESS "Whitelist multi-remove: $removed_total"
            echo "[✓] Removed the selected domain(s) from whitelist and re-blocked them."
            refresh_blocked_counts
            update_status
            end_time=$(get_current_time)
            log_duration "Removing from whitelist: $raw_input" "$start_time" "$end_time"
        fi
        ;;

    --blacklist|-b)
        start_time=$(get_current_time)
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."
        option="$2"
        shift 2 # Remove script name and option from arguments

        if [ "$option" != "add" ] && [ "$option" != "remove" ] || [ $# -eq 0 ]; then
            echo "Usage: rmlwk --blacklist, -b <add/remove> <domain1> [domain2] [domain3] ..."
            display_blacklist=$(cat "$persist_dir/blacklist.txt" 2>/dev/null || true)
            [ ! -z "$display_blacklist" ] && echo -e "Current blacklist:\n$display_blacklist" || echo "Current blacklist: no saved blacklist"
            exit 1
        fi
        touch "$persist_dir/blacklist.txt"
        if [ "$option" = "add" ]; then
            # Process multiple domains for addition (but only first one for now to maintain compatibility)
            raw_input="$1"

            # Sanitize input
            if printf "%s" "$raw_input" | grep -qE '^https?://'; then
                domain=$(printf "%s" "$raw_input" | awk -F[/:] '{print $4}')
            else
                domain="$raw_input"
            fi

            # Validate domain format
            if ! printf '%s' "$domain" | grep -qiE '^[a-z0-9.-]+\.[a-z]{2,}$'; then
                echo "[!] Invalid domain: $domain"
                echo "Example valid domain: example.com"
                exit 1
            fi

            # Ensure domain not already whitelisted
            if grep -Fxq "$domain" "$persist_dir/whitelist.txt"; then
                echo "[!] Cannot blacklist $domain, it already exists in whitelist."
                exit 1
            fi

            # Add to hosts file if not already present
            if grep -qE "^0\.0\.0\.0[[:space:]]+$domain\$" "$hosts_file"; then
                echo "[!] $domain is already blocked."
                exit 1
            else
                echo "[*] Blacklisting $domain..."
                log_message "Blacklisting $domain..."
                # Add to blacklist.txt if not already there
                grep -qxF "$domain" "$persist_dir/blacklist.txt" || echo "$domain" >> "$persist_dir/blacklist.txt"
                # Ensure newline at end before appending
                [ -s "$hosts_file" ] && tail -c1 "$hosts_file" | grep -qv $'\n' && echo "" >> "$hosts_file"
                echo "0.0.0.0 $domain" >> "$hosts_file" && echo "[✓] Blacklisted $domain."
                log_message SUCCESS "Done added $domain to hosts file and blacklist."
            fi
            refresh_blocked_counts
            update_status
            end_time=$(get_current_time)
            log_duration "Adding to blacklist: $domain" "$start_time" "$end_time"
        else
            # Remove multiple domains from blacklist
            log_message "Removing multiple domains from blacklist: $*"

            total_removed=0
            failed_removals=""

            for domain_to_remove in "$@"; do
                # Sanitize input
                if printf "%s" "$domain_to_remove" | grep -qE '^https?://'; then
                    domain=$(printf "%s" "$domain_to_remove" | awk -F[/:] '{print $4}')
                else
                    domain="$domain_to_remove"
                fi

                echo "[*] Removing $domain from blacklist..."
                log_message "Removing $domain from blacklist..."
                if grep -qxF "$domain" "$persist_dir/blacklist.txt"; then
                    sed -i "/^$(printf '%s' "$domain" | sed 's/[]\/$*.^|[]/\\&/g')$/d" "$persist_dir/blacklist.txt"
                    tmp_hosts="$persist_dir/tmp.hosts.$$"
                    grep -vF "0.0.0.0 $domain" "$hosts_file" > "$tmp_hosts"
                    cat "$tmp_hosts" > "$hosts_file"
                    rm -f "$tmp_hosts"
                    log_message "Removed $domain from blacklist and unblocked."
                    echo "[✓] $domain has been removed from blacklist and unblocked."
                    total_removed=$((total_removed + 1))
                else
                    echo "[!] $domain isn't found in blacklist."
                    failed_removals="$failed_removals $domain_to_remove"
                    log_message WARN "$domain not found in blacklist"
                fi
            done

            # Summary
            if [ $total_removed -gt 0 ]; then
                echo "[i] Successfully removed $total_removed domain(s) from blacklist"
                log_message SUCCESS "Successfully removed $total_removed domains from blacklist"
                refresh_blocked_counts
                update_status
                end_time=$(get_current_time)
                log_duration "Removing from blacklist: $*" "$start_time" "$end_time"
            fi
            
            if [ -n "$failed_removals" ]; then
                echo "[i] Failed to remove:$failed_removals"
                log_message WARN "Failed to remove domains:$failed_removals"
            fi
            
            if [ $total_removed -eq 0 ]; then
                echo "[!] No domains were removed from blacklist"
                exit 1
            fi
        fi
        ;;

	--custom-source|-c)
        option="$2"
        shift 2 # Remove script name and option from arguments        
        if [ -z "$option" ] || [ $# -eq 0 ]; then
            echo "[!] Missing arguments."
            echo "Usage: rmlwk --custom-source <add/remove> <domain1> [domain2] [domain3] ..."
            display_sources=$(cat "$persist_dir/sources.txt" 2>/dev/null)
            [ -n "$display_sources" ] && echo -e "Current sources:\n$display_sources" || echo "Current sources: no saved sources"
            exit 1
        fi

        if [ "$option" != "add" ] && [ "$option" != "remove" ] && [ "$option" != "edit" ] && [ "$option" != "enable" ] && [ "$option" != "disable" ]; then
            echo "[!] Invalid option: Use 'add', 'remove', 'edit', 'enable', or 'disable'."
            echo "Usage: rmlwk --custom-source <add/remove/edit/enable/disable> <domain1> [domain2] [domain3] ..."
            exit 1
        fi
        touch "$persist_dir/sources.txt"
        if [ "$option" = "add" ]; then
            # For add, process the first argument as domain and the rest as the name
            domain="$1"
            shift
            name="$*"
            
            # Validate URL format (accept http/https)
            if ! printf '%s' "$domain" | grep -qiE '^(https?://[a-z0-9.-]+\.[a-z]{2,}(/.*)?|[a-z0-9.-]+\.[a-z]{2,})' ; then
                echo "[!] Invalid domain: $domain"
                echo "Example valid domain: example.com, https://example.com or https://example.com/hosts.txt"
                exit 1
            fi

            # Check if domain already exists, ignoring the comment part
            if awk '{print $1}' "$persist_dir/sources.txt" 2>/dev/null | grep -qx "$domain"; then
                echo "[!] $domain is already in sources."
            else
                if [ -n "$name" ]; then
                    echo "$domain # $name" >> "$persist_dir/sources.txt"
                    log_message SUCCESS "Added $domain ($name) to sources."
                    echo "[✓] Added $domain ($name) to sources."
                else
                    echo "$domain" >> "$persist_dir/sources.txt"
                    log_message SUCCESS "Added $domain to sources."
                    echo "[✓] Added $domain to sources."
                fi
            fi
        elif [ "$option" = "edit" ]; then
            old_domain="$1"
            new_domain="$2"
            shift 2
            new_name="$*"

            # Validate URL format
            if ! printf '%s' "$new_domain" | grep -qiE '^(https?://[a-z0-9.-]+\.[a-z]{2,}(/.*)?|[a-z0-9.-]+\.[a-z]{2,})' ; then
                echo "[!] Invalid new domain: $new_domain"
                echo "Example valid domain: example.com, https://example.com or https://example.com/hosts.txt"
                exit 1
            fi

            if awk '{print $1}' "$persist_dir/sources.txt" 2>/dev/null | grep -qx "$old_domain"; then
                awk -v dom="$old_domain" '$1 != dom' "$persist_dir/sources.txt" > "$persist_dir/sources.tmp"
                if [ -n "$new_name" ]; then
                    echo "$new_domain # $new_name" >> "$persist_dir/sources.tmp"
                    log_message SUCCESS "Edited $old_domain to $new_domain ($new_name)."
                    echo "[✓] Edited $old_domain to $new_domain ($new_name)."
                else
                    echo "$new_domain" >> "$persist_dir/sources.tmp"
                    log_message SUCCESS "Edited $old_domain to $new_domain."
                    echo "[✓] Edited $old_domain to $new_domain."
                fi
                mv "$persist_dir/sources.tmp" "$persist_dir/sources.txt"
            else
                echo "[!] $old_domain was not found in sources."
                exit 1
            fi
        elif [ "$option" = "enable" ] || [ "$option" = "disable" ]; then
            total_processed=0
            failed_process=""
            for domain in "$@"; do
                # Validate URL format
                if ! printf '%s' "$domain" | grep -qiE '^(https?://[a-z0-9.-]+\.[a-z]{2,}(/.*)?|[a-z0-9.-]+\.[a-z]{2,})' ; then
                    echo "[!] Invalid domain: $domain"
                    failed_process="$failed_process $domain"
                    continue
                fi

                if awk '{print $1}' "$persist_dir/sources.txt" 2>/dev/null | grep -qx "#" || awk '{print $1}' "$persist_dir/sources.txt" 2>/dev/null | grep -qx "$domain" || awk '{print $4}' "$persist_dir/sources.txt" 2>/dev/null | grep -qx "$domain"; then
                    if [ "$option" = "enable" ]; then
                        sed -i "s|^# OFF # $domain|$domain|g" "$persist_dir/sources.txt"
                        log_message SUCCESS "Enabled $domain in sources."
                        echo "[✓] Enabled $domain in sources."
                    else
                        sed -i "s|^$domain|# OFF # $domain|g" "$persist_dir/sources.txt"
                        log_message SUCCESS "Disabled $domain in sources."
                        echo "[✓] Disabled $domain in sources."
                    fi
                    total_processed=$((total_processed + 1))
                else
                    echo "[!] $domain was not found in sources."
                    log_message WARN "$domain not found in sources"
                    failed_process="$failed_process $domain"
                fi
            done
            
            # Summary
            if [ $total_processed -gt 0 ]; then
                echo "[i] Successfully processed $total_processed source(s)"
            fi
            
            if [ -n "$failed_process" ]; then
                echo "[i] Failed to process:$failed_process"
            fi
            
            if [ $total_processed -eq 0 ]; then
                echo "[!] No sources were processed"
                exit 1
            fi
        else
            # Remove multiple domains from sources
            log_message "Removing multiple domains from sources: $*"
            total_removed=0
            failed_removals=""
            for domain_to_remove in "$@"; do
                # Validate URL format
                if ! printf '%s' "$domain_to_remove" | grep -qiE '^(https?://[a-z0-9.-]+\.[a-z]{2,}(/.*)?|[a-z0-9.-]+\.[a-z]{2,})' ; then
                    echo "[!] Invalid domain format: $domain_to_remove"
                    failed_removals="$failed_removals $domain_to_remove"
                    continue
                fi

                # Check correctly by filtering out the prefix if present
                if grep -E "^(# OFF # )?$domain_to_remove" "$persist_dir/sources.txt" >/dev/null 2>&1; then
                    # Remove the line matching the domain (even if it has a comment after it or # OFF # prefix)
                    awk -v dom="$domain_to_remove" '{
                        actual=$1; 
                        if (actual=="#") actual=$4; 
                        if (actual != dom) print $0
                    }' "$persist_dir/sources.txt" > "$persist_dir/sources.tmp"
                    mv "$persist_dir/sources.tmp" "$persist_dir/sources.txt"
                    log_message SUCCESS "Removed $domain_to_remove from sources."
                    echo "[✓] Removed $domain_to_remove from sources."
                    total_removed=$((total_removed + 1))
                else
                    echo "[!] $domain_to_remove was not found in sources."
                    failed_removals="$failed_removals $domain_to_remove"
                    log_message WARN "$domain_to_remove not found in sources"
                fi
            done
            
            # Summary
            if [ $total_removed -gt 0 ]; then
                echo "[i] Successfully removed $total_removed source(s)"
                log_message SUCCESS "Successfully removed $total_removed sources"
            fi
            
            if [ -n "$failed_removals" ]; then
                echo "[i] Failed to remove:$failed_removals"
                log_message WARN "Failed to remove sources:$failed_removals"
            fi
            
            if [ $total_removed -eq 0 ]; then
                echo "[!] No sources were removed"
                exit 1
            fi
        fi
        if [ "$profile" != "custom" ]; then
            if [ "$option" = "add" ] || [ "$option" = "edit" ] || [ "$option" = "remove" ]; then
                sed -i 's/^profile=.*/profile=custom/' "$persist_dir/config.sh"
                log_message SUCCESS "Profile automatically set to custom due to source modification."
                update_status
            fi
        fi
        ;;

    --custom-rule|-cr)
        start_time=$(get_current_time)
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."
        option="$2"
        shift 2

        if [ -z "$option" ] || [ $# -eq 0 ]; then
            echo "[!] Missing arguments."
            echo "Usage: rmlwk --custom-rule <add|remove> <IP> <domain>"
            display_rules=$(cat "$persist_dir/custom_rules.txt" 2>/dev/null)
            [ -n "$display_rules" ] && echo -e "Current custom rules:\n$display_rules" || echo "Current custom rules: no saved custom rules"
            exit 1
        fi

        if [ "$option" != "add" ] && [ "$option" != "remove" ]; then
            echo "[!] Invalid option: Use 'add' or 'remove'."
            echo "Usage: rmlwk --custom-rule <add/remove> <IP> <domain>"
            exit 1
        fi

        touch "$persist_dir/custom_rules.txt"
        if [ "$option" = "add" ]; then
            if [ $# -lt 2 ]; then
                echo "[!] Incomplete input."
                echo "[i] Usage: rmlwk --custom-rule add <IP> <domain>"
                exit 1
            fi
            ip="$1"
            domain="$2"

            # Validate IP format
            if ! printf '%s' "$ip" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$|^[0-9a-fA-F:]+$'; then
                echo "[!] Invalid IP format: $ip"
                exit 1
            fi

            # Validate Domain or IP format
            if ! printf '%s' "$domain" | grep -qiE '^[a-z0-9.-]+\.[a-z]{2,}$|^([0-9]{1,3}\.){3}[0-9]{1,3}$|^[0-9a-fA-F:]+$'; then
                echo "[!] Invalid domain or IP format: $domain"
                exit 1
            fi

            # Check if domain already has a custom rule
            if awk '{print $2}' "$persist_dir/custom_rules.txt" 2>/dev/null | grep -qx "$domain"; then
                echo "[!] Domain $domain already has a custom rule."
                exit 1
            else
                echo "$ip $domain" >> "$persist_dir/custom_rules.txt"
                log_message SUCCESS "Added custom rule: $ip $domain"
                echo "[✓] Added custom rule: $ip $domain"

                # Append to active hosts immediately if not present
                [ -s "$hosts_file" ] && tail -c1 "$hosts_file" | grep -qv $'\n' && echo "" >> "$hosts_file"
                echo "$ip $domain" >> "$hosts_file"
            fi

        elif [ "$option" = "remove" ]; then
            log_message "Removing multiple domains from custom rules: $*"
            total_removed=0
            failed_removals=""
            for domain_to_remove in "$@"; do
                if grep -qw "$domain_to_remove" "$persist_dir/custom_rules.txt"; then
                    awk -v dom="$domain_to_remove" '$2 != dom' "$persist_dir/custom_rules.txt" > "$persist_dir/custom_rules.tmp"
                    mv "$persist_dir/custom_rules.tmp" "$persist_dir/custom_rules.txt"

                    # Remove from active hosts too
                    tmp_hosts="$persist_dir/tmp.hosts.$$"
                    grep -vE "^[0-9a-fA-F:.]+ $domain_to_remove\$" "$hosts_file" > "$tmp_hosts" || true
                    cat "$tmp_hosts" > "$hosts_file"
                    rm -f "$tmp_hosts"

                    log_message SUCCESS "Removed custom rule for $domain_to_remove."
                    echo "[✓] Removed custom rule for $domain_to_remove."
                    total_removed=$((total_removed + 1))
                else
                    echo "[!] $domain_to_remove was not found in custom rules."
                    failed_removals="$failed_removals $domain_to_remove"
                    log_message WARN "$domain_to_remove not found in custom rules"
                fi
            done

            if [ $total_removed -gt 0 ]; then
                echo "[i] Successfully removed $total_removed custom rule(s)"
            fi
            if [ -n "$failed_removals" ]; then
                echo "[i] Failed to remove rules for:$failed_removals"
            fi
            if [ $total_removed -eq 0 ]; then
                echo "[!] No custom rules were removed"
                exit 1
            fi
        fi

        refresh_blocked_counts
        update_status
        end_time=$(get_current_time)
        log_duration "Custom rule action: $option" "$start_time" "$end_time"
        ;;

    --auto-update|-a)
        case "$2" in
            enable)
                enable_auto_update
                ;;
            disable)
                disable_auto_update
                ;;
            *)
                echo "[!] Invalid option for --auto-update / -a"
                echo "Usage: rmlwk <--auto-update|-a> <enable|disable>"
                ;;
        esac
        ;;

    --update-hosts|-u)
        start_time=$(get_current_time)
        awk '!/^#|^$/' $persist_dir/sources.txt | grep http > /dev/null || abort "No hosts sources were found, Aborting."
        is_protection_paused && abort "Ad-block is paused. Please resume before running this command."

        if [ -d /data/adb/modules/Re-Malwack ]; then
            echo "[*] Upgrading Anti-Ads fortress 🏰"
            log_message "Updating protections..."
        else
            echo "[*] Building Anti-Ads fortress 🏰"
            log_message "Installing protection for the first time"
        fi
        check_internet
        combined_file="${tmp_hosts}_all"
        > "$combined_file"

        # 1 - Download base hosts from sources.txt with limited parallelism to prevent resource exhaustion
        echo "[*] Fetching base hosts..."
        log_message "Starting download of base hosts"
        # Extract only the URLs for fetching (ignore inline comments too)
        hosts_list=$(awk '!/^#|^$/ {print $1}' "$persist_dir/sources.txt" | sort -u)
        counter=0
        download_limit=3
        download_count=0
        for host in $hosts_list; do
            counter=$((counter + 1))
            # Save the url mapping for this counter for later counting
            echo "$host" > "${tmp_hosts}${counter}.url"
            fetch "${tmp_hosts}${counter}" "$host" &
            download_count=$((download_count + 1))
            # Limit concurrent downloads
            [ "$download_count" -ge "$download_limit" ] && { wait; download_count=0; sleep 0.5; }
        done
        wait
        log_message SUCCESS "Completed download hosts from $counter source(s)"

        # 1.1 - Process in parallel with conservative limits
        job_limit=3
        job_count=0
        mkdir -p "$persist_dir/counts"
        > "$persist_dir/counts/sources.counts"
        for i in $(seq 1 $counter); do
            (
                if [ -f "${tmp_hosts}${i}" ]; then
                    host_process "${tmp_hosts}${i}"
                    # Count block entries and save it
                    if [ -f "${tmp_hosts}${i}.url" ]; then
                        host_url=$(cat "${tmp_hosts}${i}.url")
                        entries_count=$(wc -l < "${tmp_hosts}${i}")
                        echo "${host_url}|${entries_count}" >> "$persist_dir/counts/sources.counts"
                        log_message SUCCESS "Downloaded $entries_count entries from $host_url"
                    fi
                    cat "${tmp_hosts}${i}" >> "$combined_file"
                fi
            ) &
            job_count=$((job_count + 1))
            [ "$job_count" -ge "$job_limit" ] && { wait; job_count=0; sleep 0.25; }
        done
        wait
        log_message "Completed processing of all source files"

        # 2 - Download & process blocklists with small delays to prevent resource starvation
        > "$persist_dir/counts/blocklists.counts"
        for bl in porn gambling fakenews social trackers safebrowsing; do
            block_var="block_${bl}"
            eval enabled=\$$block_var

            # 2.1 - Skip if not enabled
            [ "$enabled" = "0" ] && continue

            # 2.1 - Prepare blocklist fetch
            echo "[*] Fetching blocklist: $bl"
            log_message "Fetching blocklist: $bl"
            mkdir -p "$persist_dir/cache/$bl"

            # 2.3 - Fetch blocklists
            fetch_blocklist "$bl"

            # 2.4 - Process blocklists
            bl_count=0
            for file in "$persist_dir/cache/$bl/hosts"*; do
                if [ -f "$file" ]; then
                    host_process "$file"
                    file_count=$(wc -l < "$file")
                    bl_count=$((bl_count + file_count))
                fi
            done
            echo "${bl}|${bl_count}" >> "$persist_dir/counts/blocklists.counts"

            # 2.5 - Append to combined file
            cat "$persist_dir/cache/$bl/hosts"* >> "$combined_file"
            echo "[✓] Fetched $bl blocklist"
            log_message "Added $bl ($bl_count) hosts entries to combined hosts"
        done

        # 3 - Install hosts
        echo "[*] Installing hosts"
        log_message "Writing new hosts file"
        printf "127.0.0.1 localhost\n::1 localhost" > "$hosts_file"
        install_hosts "all"

        # 4 - Done
        refresh_blocked_counts
        update_status
        log_message SUCCESS "Successfully updated all hosts."
        [ ! "$MODDIR" = "/data/adb/modules_update/Re-Malwack" ] && echo "[✓] Everything is now Good!"
        end_time=$(get_current_time)
        log_duration "Updating hosts" "$start_time" "$end_time"
        ;;

    --help|-h|*)
        echo ""
        echo "[i] Usage: rmlwk [--argument] OPTIONAL: [--quiet]"
        echo "--update-hosts, -u: Update the hosts file."
        echo "--profile, -p <default|lite|balanced|aggressive|custom>: Switch adblock level profile."
        echo "--auto-update, -a <enable|disable>: Toggle auto hosts update."
        echo "--custom-source, -c <add|remove|edit> ...: Add/remove/edit custom hosts sources."
        echo "--custom-rule, -cr <add|remove> <IP> <domain>: Add or remove custom hosts rules."
        echo "--reset, -r: Reset hosts file to default."
        echo "--query-domain, -q <domain>: Query if a domain is blocked, redirected, or not blocked."
        echo "--adblock-switch, -as: Toggle protections on/off."
        echo "--block-trackers, -bt <disable>, block trackers, use disable to unblock."
        echo "--block-porn, -bp <disable>: Block pornographic sites, use disable to unblock."
        echo "--block-gambling, -bg <disable>: Block gambling sites, use disable to unblock."
        echo "--block-fakenews, -bf <disable>: Block fake news sites, use disable to unblock."
        echo "--block-social, -bs <disable>: Block social media sites, use disable to unblock."
        echo "--whitelist, -w <add|remove> <domain|pattern> <domain2> ...: Whitelist domain(s), only whitelist one domain at a time, otherwise use wildcard or use multiple domains in case of unwhitelisting."
        echo "--blacklist, -b <add|remove> <domain1> <domain2> ...: Blacklist domain(s)."
        echo "--export-logs, -e: Export logs to a tarball in Download directory."
        echo "--help, -h: Display help."
        echo -e "\033[0;31m Example command: su -c rmlwk --update-hosts\033[0m"
        ;;
esac
