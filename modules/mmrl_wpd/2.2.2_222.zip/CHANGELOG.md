<divider textAlign="left"><h1>2.2.2</h1></divider>

- Fixed missing components