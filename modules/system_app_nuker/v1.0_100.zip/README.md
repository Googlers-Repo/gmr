
# System App Nuker

A simple and efficient module that allows you to remove pre-installed system apps from your Android device.

## Features
- Web-based Interface – Select apps to remove using a simple WebUI.

- Removing system apps without touching the original partitions.

## Installation and Usage
1. Download the latest release module.
2. Install the module.
3. Reboot your device.
4. Open the WebUI and select app you want to remove.
5. Reboot your device.

## Disclaimer
Use at your own risk. Removing critical system apps may cause instability.
