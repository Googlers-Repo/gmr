# Translation Contributor List

## Arabic

- [ZG089](https://github.com/ZG089)

---

## Chinese (Simplified)

- [xiangfa-test](https://github.com/xiangfa-test)

---

## Czech

- [Jonáš Nedvědický](https://github.com/PhateValleyman)

---

## French

- [dimatteo](https://github.com/dimatteo)

---

## German

- [Vndkbopp77](https://github.com/Vndkbopp77)
- [acmor](https://github.com/acmor)

---

## Greek

- [VisionR1](https://github.com/VisionR1)

---

## Indonesian

- [Rem01Gaming](https://github.com/Rem01Gaming)
- [Mesazane](https://github.com/mesazane)
- [Neebe3289](https://github.com/Neebe3289)

---

## Italian

- [luigimak](https://github.com/luigimak)

---

## Japanese

- [Mahiru](https://github.com/Nanaco3)
- [reindex-ot](https://github.com/reindex-ot)
- [nana7](https://crowdin.com/profile/nana7)

---

## Polish

- [Bladius2024](https://github.com/Bladius2024)

---

## Portuguese (Brazilian)

- [SecretGogeta](https://crowdin.com/profile/secretgogeta)
- [Isac Campelo](https://crowdin.com/profile/isaccampelo192)

---

## Russian

- [lynx](https://github.com/thisdialynx)
- [0dinsky](https://github.com/0dinsky)
- [Tihonov Matvey](https://crowdin.com/profile/rythmical)
- [vertekplus](https://github.com/vertekplus)

---

## Spanish

- [Lxchoooo](https://github.com/Lxchoooo)

---

## Sweden

- [Sopor](https://github.com/Sopor)

---

## Turkish

- [berkmirsatk](https://github.com/berkmirsatk)

---

## Ukrainian

- [lynx](https://github.com/thisdialynx)
- [Nick Kernitsky](https://crowdin.com/profile/mkern)
