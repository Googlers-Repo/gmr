For support this project: [Patreon](https://avalibeyaz.com/patreon)  
--------------  
## v2.0.2
- Try to use KernelSU's new feature "webroot html UI" (thanks to [0x0021](https://github.com/0x0021))
  
## v2.0.1
- Android 14 stable release
- Removed some debug functions for A14
- Updated README.md
- Changed versionCode structure to xxyyzz (for example for v2.0.1 is 020001, not 201 now)
  
## v2.0.0
### !!! Warning! This is a beta update, it my not work! If you want to test whether the Android 14 patch works, update it and report working status to [issues](https://github.com/symbuzzer/livebootmodule/issues). Otherwise, stay with the current version and wait for later versions. 
- Added Android 14 support, thanks to [Chainfire](https://github.com/Chainfire)/[LiveBoot](https://github.com/Chainfire/liveboot)

## v1.1.2  
- Updated README.md  
  
## v1.1.1  
- Fixed disabling module
  
## v1.1.0  
- Project and module name changed to "livebootmodule" from "livebootmagisk"
  
## v1.0.6    
- Fixed critical issue
- Necessary changes were made to change the project name 
  
## v1.0.5 (Unreleased)  
- Necessary changes were made to change the project name  
  
## v1.0.4  
- Changed update url with general one
- Modified author info  
  
## v1.0.3  
- Added KernelSU support  
    
## v1.0.2  
- Added create&release workflow
  
## v1.0.1  
- Fixed changelog.md path bug  
- Changed description of the module  
- Added updated README.md etc file to the module  
  
## v1.0.0  
- Initial release  
