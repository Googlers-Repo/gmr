install_script -p $MODPATH/0000bootlive
install_script -l $MODPATH/0000bootlive