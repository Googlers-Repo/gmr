## Change logs

# v1.1.2
* Added a support for APatch

# v1.1.1
* Fixed a permission bug
* Changed to use exact folder names in command executions instead of recursion options

# v1.1.0
* Fixed a bug of providing modified system files (added "mount --make-private each-partition")

# v1.0.1
* Changed ksu-magisk more harmless

# v1.0.0
* Initial Release

##
