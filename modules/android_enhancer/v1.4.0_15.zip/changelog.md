# v1.4.0

- [Module] Fixed duplicate module issue
- [Module] Added support for KernelSU and APatch
- [Module] Misc. changes
- [Core] Removed memory lock tweak
- [Core] Improved /util
- [Core] Added focused app optimizer
- [Core] Improved overall tweaks
- [Core] Improved commandline arguments
- [Core] Misc. changes