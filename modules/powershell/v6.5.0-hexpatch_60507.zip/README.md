# PowerShell

![](https://raw.githubusercontent.com/DerGoogler/powershell/master/assets/cover.png)

## Example 

```powershell
powershell file.ps1
```