# Android Enhancer Module 🚀

The module version of Android Enhancer.

## Download 📲

[Click here](https://www.pling.com/p/1875251/) to download the latest version of Android Enhancer Module.

## Notes 📝

- This is a module, so you will need to flash it. It works on Magisk, KernelSU, and APatch.
- You can find the `android_enhancer.log` file in Internal Storage/Android. It will show you the types of tweaks Android Enhancer has applied.
- The device may overheat while the tweaks are being executed, but there's no need to worry. The overheating will subside after some time, once the tweaks are fully completed.