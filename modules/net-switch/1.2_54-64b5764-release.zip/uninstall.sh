#!/bin/sh

# remove configs
rm -rf /data/adb/net-switch

# clean our symlinks
rm /data/adb/ap/bin/netswitch
rm /data/adb/ksu/bin/netswitch
