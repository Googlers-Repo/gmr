rm -f "$MODPATH/update.json"
setup_native_libs