# 0.3.7

- Fixed ModConf error
