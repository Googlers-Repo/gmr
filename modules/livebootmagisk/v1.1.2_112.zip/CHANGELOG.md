For support this project: [Patreon](https://avalibeyaz.com/patreon)  
--------------  
## v1.1.2  
- Updated README.md  
  
## v1.1.1  
- Fixed disabling module
  
## v1.1.0  
- Project and module name changed to "livebootmodule" from "livebootmagisk"
  
## v1.0.6    
- Fixed critical issue
- Necessary changes were made to change the project name 
  
## v1.0.5 (Unreleased)  
- Necessary changes were made to change the project name  
  
## v1.0.4  
- Changed update url with general one
- Modified author info  
  
## v1.0.3  
- Added KernelSU support  
    
## v1.0.2  
- Added create&release workflow
  
## v1.0.1  
- Fixed changelog.md path bug  
- Changed description of the module  
- Added updated README.md etc file to the module  
  
## v1.0.0  
- Initial release  
