const t=`<div class="body-content constant-height">
    <!-- Source box -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="source_title"></h2>
            <button class="help-btn" data-type="sources">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <div class="category-container">
            <div class="input-box-wrapper translucent">
                <textarea autocapitalize="off" class="input-box" rows="1" id="sources-input" type="text" placeholder="https://adaway.org/hosts.txt"></textarea>
            </div>
            <button class="add-btn ripple-element" id="sources-add">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
        <ul id="sources-list"></ul>
    </div>

    <!-- Whitelist source box -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="sources_whitelist_title"></h2>
            <button class="help-btn" data-type="sources_whitelist">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <div class="category-container">
            <div class="input-box-wrapper translucent">
                <textarea autocapitalize="off" class="input-box" rows="1" id="sources_whitelist-input" type="text" placeholder="https://example.com/whitelist_txt"></textarea>
            </div>
            <button class="add-btn ripple-element" id="sources_whitelist-add">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
        <ul id="sources_whitelist-list"></ul>
    </div>

    <!-- Whitelist box -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="whitelist_title"></h2>
            <button class="help-btn" data-type="whitelist">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <div class="category-container">
            <div class="input-box-wrapper translucent">
                <textarea autocapitalize="off" class="input-box" rows="1" id="whitelist-input" type="text" placeholder="s.youtube.com"></textarea>
            </div>
            <button class="add-btn ripple-element" id="whitelist-add">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
        <ul id="whitelist-list"></ul>
    </div>

    <!-- Blacklist box -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="blacklist_title"></h2>
            <button class="help-btn" data-type="blacklist">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <div class="category-container">
            <div class="input-box-wrapper translucent">
                <textarea autocapitalize="off" class="input-box" rows="1" id="blacklist-input" type="text" placeholder="online-casino.com"></textarea>
            </div>
            <button class="add-btn ripple-element" id="blacklist-add">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
        <ul id="blacklist-list"></ul>
    </div>

    <!-- Custom box -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="custom_title"></h2>
            <button class="help-btn" data-type="custom">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <div class="category-container">
            <div class="input-box-wrapper translucent">
                <textarea autocapitalize="off" class="input-box" rows="1" id="custom-input" type="text" placeholder="93.184.215.14 example.com"></textarea>
            </div>
            <button class="add-btn ripple-element" id="custom-add">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
        <ul id="custom-list"></ul>
    </div>

    <!-- Import custom hosts -->
    <div class="box translucent">
        <div>
            <h2 data-i18n="import_custom_title"></h2>
            <button class="help-btn" data-type="import_custom">
                <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px"><path d="M475-240q25 0 43-18t18-43.14q0-25.14-18-42.5T475-361q-25 0-43 17.36t-18 42.5Q414-276 432-258t43 18Zm-47-154h94q0-29 8-49t38-49q23-22 37.5-47.06 14.5-25.05 14.5-60.23 0-59.71-39-91.21-39-31.5-95-31.5-61 0-101.5 35T328-604l88 33q7-20 22-40t43-20q20 0 31 12.5t11 27.5q0 15-10.5 31T491-535q-40 37-51.5 60.5T428-394Zm52 348q-91 0-169.99-34.08-78.98-34.09-137.41-92.52-58.43-58.43-92.52-137.41Q46-389 46-480q0-91 34.08-169.99 34.09-78.98 92.52-137.41 58.43-58.43 137.41-92.52Q389-914 480-914q91 0 169.99 34.08 78.98 34.09 137.41 92.52 58.43 58.43 92.52 137.41Q914-571 914-480q0 91-34.08 169.99-34.09 78.98-92.52 137.41-58.43 58.43-137.41 92.52Q571-46 480-46Z"/></svg>
            </button>
        </div>
        <ul id="import_custom-list"></ul>
        <div class="import-button-container">
            <button class="import-button ripple-element" id="import-custom-button">
                <svg xmlns="http://www.w3.org/2000/svg" height="22px" viewBox="0 -960 960 960" width="22px" fill="#ffffff"><path d="M417-417H166v-126h251v-251h126v251h251v126H543v251H417v-251Z"/></svg>
            </button>
        </div>
    </div>

    <!-- Safe inset -->
    <div class="placeholder"></div>
</div>

<!-- Edit workspace -->
<div class="document-cover translucent constant-height blur-box"></div>
<div class="constant-height slide-menu" id="edit-content">
    <div class="line-numbers"></div>
    <textarea class="edit-input blur-box" id="edit-input"></textarea>
</div>

<!-- Action terminal -->
<div class="constant-height blur-box slide-menu blur-box" id="action-terminal">
    <div class="terminal" id="action-terminal-content"></div>
</div>

<!-- Help overlay -->
<div id="sources-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="source_title"></h2>
        <ul>
            <li data-i18n="source_guide1"></li>
            <li>
                <p data-i18n="source_format"></p>
                <p class="format">127.0.0.1 some.ads.site</p>
                <p class="format">0.0.0.0 some.ads.site</p>
            </li>
            <li>
                <p data-i18n="source_example"></p>
                <p>https://adaway.org/hosts.txt</p>
                <p>https://raw.githubusercontent.com/r-a-y/mobile-hosts/master/AdguardDNS.txt</p>
            </li>
            <br>
            <li data-i18n="source_guide2"></li>
            <li>
                <p data-i18n="source_format"></p>
                <p class="format">186.2.163.20 nyaa.si</p>
            </li>
            <li>
                <p data-i18n="source_example"></p>
                <p>https://raw.githubusercontent.com/bebasid/bebasid/refs/heads/master/releases/hosts</p>
            </li>
        </ul>
        <div class="source-btn-wrapper">
            <button class="docs-btn ripple-element" id="source-btn" data-type="source" data-i18n="source_source_page"></button>
        </div>
    </div>
</div>
<div id="sources_whitelist-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="sources_whitelist_title"></h2>
        <ul>
            <li data-i18n="sources_whitelist_guide1"></li>
            <li>
                <p data-i18n="sources_whitelist_format"></p>
                <p>some.site.one</p>
                <p>some.site.two</p>
            </li>
            <li>
                <p data-i18n="sources_whitelist_example"></p>
                <p>https://raw.githubusercontent.com/anudeepND/whitelist/master/domains/whitelist.txt</p>
            </li>
        </ul>
    </div>
</div>
<div id="whitelist-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="whitelist_title"></h2>
        <ul>
            <li data-i18n="whitelist_guide1"></li>
            <li>
                <p data-i18n="whitelist_example"></p>
                <p>host.not.to.block</p>
            </li>
        </ul>
    </div>
</div>
<div id="blacklist-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="blacklist_title"></h2>
        <ul>
            <li data-i18n="blacklist_guide1"></li>
            <li>
                <p data-i18n="blacklist_example"></p>
                <p>host.to.block</p>
            </li>
        </ul>
    </div>
</div>
<div id="custom-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="custom_title"></h2>
        <ul>
            <li data-i18n="custom_guide1"></li>
            <li>
                <p data-i18n="custom_example"></p>
                <p class="format">1.1.1.1 one.one.one.one</p>
                <p class="format">93.184.215.14 example.com</p>
            </li>
            <li data-i18n="custom_warning"></li>
        </ul>
    </div>
</div>
<div id="import_custom-help" class="overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <h2 data-i18n="import_custom_title"></h2>
        <ul>
            <li data-i18n="custom_guide1"></li>
            <li>
                <p data-i18n="custom_format"></p>
                <p class="format">1.1.1.1 one.one.one.one</p>
                <p class="format">93.184.215.14 example.com</p>
            </li>
            <li data-i18n="custom_warning"></li>
        </ul>
    </div>
</div>

<!-- Source docs overlay -->
<div id="source-docs" class="docs overlay">
    <div class="docs-content blur-box">
        <button class="close-btn">&#x2715;</button>
        <div class="documents">
            <div id="source-content">Loading...</div>
            <div class="credit-marked">Markdown Parser by markedjs/marked</div>
        </div>
    </div>
</div>

<!-- Confirmation dialog overlay -->
<div class="overlay" id="confirmation-overlay">
    <div class="overlay-content blur-box">
        <button class="close-btn" id="close-confirmation"></button>
        <h2 data-i18n="confirmation_title"></h2>
        <p>
            <span data-i18n="confirmation_message"></span>
            <span id="confirmation-file-name"></span>
        </p>
        <div class="confirm-btn-container">
            <button class="confirm-btn ripple-element" id="cancel-btn" data-i18n="confirmation_cancel"></button>
            <button class="confirm-btn ripple-element" id="remove-btn" data-i18n="confirmation_remove"></button>
        </div>
    </div>
</div>

<!-- Action button -->
<div class="float action-container">
    <button id="force-update-btn" class="force-update-button ripple-element">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px"><path d="m296-224-56-56 240-240 240 240-56 56-184-183-184 183Zm0-240-56-56 240-240 240 240-56 56-184-183-184 183Z"/></svg>
    </button>
    <button id="action-btn" class="action-button ripple-element">
        <svg xmlns="http://www.w3.org/2000/svg" height="34px" viewBox="0 -960 960 960" width="34px"><path d="M320-200v-560l440 280-440 280Z"/></svg>
        <button id="close-terminal" class="action-button ripple-element">
            <svg xmlns="http://www.w3.org/2000/svg" height="34px" viewBox="0 -960 960 960" width="34px"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg>
        </button>
    </button>
</div>
`;export{t as default};
