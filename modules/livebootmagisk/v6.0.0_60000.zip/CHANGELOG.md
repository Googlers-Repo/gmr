To support this project: [Patreon](https://avalibeyaz.com/patreon)
--------------
## v6.0.0 *(Thanks to [EmilienCourt](https://github.com/EmilienCourt))*
- Added Android 16 support
- Update Liveboot APK to use [AntiOblivionis' working fork](https://github.com/AntiOblivionis/liveboot)
- Update config accordingly
- Update loader.sh to use de-minified version

## v5.0.0
- Code refactor

## v4.0.0
- Removed MMRL mod configuration feature because it doesn't work anymore

## v3.0.3  
- Code splitting for MMRL's mod configuration (Thanks to [DerGoogler](https://github.com/DerGoogler))
- Fixed a bug with ListItemSelectDialog (Thanks to [DerGoogler](https://github.com/DerGoogler))

## v3.0.2
- Edited README.md (Thanks to [Peter Noël Muller](https://github.com/peternmuller))

## v3.0.1  
- Added new README.md for customization guide and fixed CHANGELOG.md
  Thanks to [DerGoogler](https://github.com/DerGoogler) and [Peter Noël Muller](https://github.com/peternmuller) for detailed customization guide

## v3.0.0
- Added configuration UI for [MMRL](https://github.com/DerGoogler/MMRL/releases) by [DerGoogler](https://github.com/DerGoogler) (Thanks to [DerGoogler](https://github.com/DerGoogler))

## v2.0.4
- Readded "install_script -l $MODPATH/0000bootlive" command to "/common/install.sh" because some devices still need it.
- Updated [MMT-Extended](https://github.com/Zackptg5/MMT-Extended/commit/4331310fb19d28e3388ae0c5f155228fdfcb178d) to 3.7

## v2.0.3
- Removed unnecessary "install_script -l $MODPATH/0000bootlive" command from "/common/install.sh"

## v2.0.2
- Try to use KernelSU's new feature "webroot html UI" (Thanks to [0x0021](https://github.com/0x0021))

## v2.0.1
- Android 14 stable release
- Removed some debug functions for A14
- Updated README.md
- Changed versionCode structure to xxyyzz (for example for v2.0.1 is 020001, not 201 now)

## v2.0.0
### !!! Warning! This is a beta update, it my not work! If you want to test whether the Android 14 patch works, update it and report working status to [issues](https://github.com/symbuzzer/livebootmodule/issues). Otherwise, stay with the current version and wait for later versions. 
- Added Android 14 support, thanks to [Chainfire](https://github.com/Chainfire)/[LiveBoot](https://github.com/Chainfire/liveboot)

## v1.1.2  
- Updated README.md

## v1.1.1  
- Fixed disabling module

## v1.1.0  
- Project and module name changed to "livebootmodule" from "livebootmagisk"

## v1.0.6    
- Fixed critical issues
- Necessary changes were made to change the project name 

## v1.0.5 (Unreleased)  
- Necessary changes were made to change the project name

## v1.0.4  
- Changed update url with a general one
- Modified author info

## v1.0.3  
- Added KernelSU support

## v1.0.2  
- Added create&release workflow

## v1.0.1  
- Fixed changelog.md path bug
- Changed module description
- Added updated README.md etc. file

## v1.0.0  
- Initial release
