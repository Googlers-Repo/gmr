# AntiAMTS for Magisk

Dies Modul wurde nicht von Sierra Developers entwickelt, der DNS Service ist jedoch von ihnen.

# Vorteile?

Ja, die gibts! Du hast kein App und Benachrichtigung, die sind nervig. Das Ganze läuft im Magisk-Systemless-Process.

## Vorteile vom Service

Diese Vorteile bietet der AntiAMTS-Service

### Websites laden schneller.

Wenn Websites sich aufbauen (Ladebalken am Tab im Browser), dann lädt es häufig langsamer, weil die Werbenetzwerke von der Website angefragt werden. Mit AMTS wird dies fast komplett umgangen.

### (fast) Keine nervige Werbung mehr.

Du kennst das: Du öffnest eine Website... es öffnet sich eine neue Seite, wo steht, dass du etwas gewonnen hast. Du öffnest dann wieder eine neue Seite und möchtest etwas dort anklicken. In dem Zeitpunkt, wo du klickst, klickt man unabsichtlich auf eine Werbeanzeige. Das gehört dann fast komplett der Vergangenheit an.

### Scammer hassen diesen Trick.

Egal ob E-Mail Spam, Tracker oder SMS Links: Die Wahrscheinlichkeit, das es dich dann auch trifft, ist dann geringer. Denn wenn du etwas unabsichtlich öffnest was schädlich ist, wird es direkt blockiert.

# Installation

Für dieses Modul wird Root benötigt. Wenn du kein Root hast, dann nehm bitte eine App als alternative.

- Repo herunterladen
- zu einer \*.zip packen
- in Magisk flashen
- Handy neu starten

# Originale Beschreibung

Anti AMTS Blocker ist eine englische Abkürzung und bedeutet: AntiAdMalwareTrackingandScam-Blocker. Sehr einfallsreicher Name, wissen wir ;). Es erleichtert das Surfen in Websites deutlich. Ein kleines Beispiel: Wenn du eine Speedtest Website oder einen Blog öffnest, kommen mehrere Werbeanzeigen. Einige stören nur, andere übertreiben es gewaltig. Mithilfe unserer Lösung können Werbung, die Tracker, die Scamseiten oder irgendwelche Gewinnspielfakes beinhalten, herausgefiltet werden. Und das Beste ist, man braucht dafür keine Software installieren, die Updates machen wir, ohne dass du was merkst.
