#!/system/bin/sh
############################################
# mm-mm uninstall.sh
# Cleanup script for metamodule removal
############################################

MODDIR="${0%/*}"

rm -rf /data/adb/magic_mount

exit 0
