## v1.5.2+ Revision 22
### These are minor changes to fix binary update to v1.5.10"
### WebUI
* WebUI: use run function to convert susfs version to a decimal version
### Scripts
* scripts/service: deprecate some futile props
### [Binaries](https://github.com/sidex15/susfs4ksu-binaries)
* binaries: update local binaries to v1.5.9
* cloud-binaries: add v1.5.10 binaries to cloud (uses v1.5.9 binaries as the latest KSU Upstream is reverted)