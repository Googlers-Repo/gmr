# 0.3.6

- Fixed Magisk install issue
- Added MMAR V2 to the default repos
- CLI handles now invalid repos
