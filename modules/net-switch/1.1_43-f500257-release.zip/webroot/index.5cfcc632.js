["/mmrl/insets.css","/mmrl/colors.css"].forEach(e=>{let s=document.createElement("link");s.rel="stylesheet",s.type="text/css",s.href=e,document.head.appendChild(s)});
//# sourceMappingURL=index.5cfcc632.js.map
