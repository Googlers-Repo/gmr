<divider textAlign="left"><h1>7.5.12</h1></divider>

- Little new toolbar design