# Anti bootloop
Protection from bootloop. Press power key at boot to disable magisk modules
