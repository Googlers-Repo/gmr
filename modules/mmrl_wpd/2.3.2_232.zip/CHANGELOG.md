<divider textAlign="left"><h1>2.3.2</h1></divider>

- Removed toolbar coloring
- Added ability to view saved bluetooth devices