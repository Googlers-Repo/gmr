# 0.3.8

- Auto find root cli's
