# 0.3.3

- Improved error handling
- Improved MMRL app support
- Added `repo` subcommand
- Added support to install local modules
- Removed download progress bar due to deadlock in MMRL
- Other improvements
- Added ModConf