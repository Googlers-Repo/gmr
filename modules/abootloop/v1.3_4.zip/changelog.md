- Added module configuration function, now you can use button combinations
> [Vol-] + [Power key], [Vol+] + [Power key], [Power key] + [Power key], [Vol+] + [Vol-]... OR just [Power key], [Vol+] and etc.
###### [Touch screen] option
[Touch screen] option is avaliable only in the button combination, this is trigering the module when you move your finger across the screen. [Touch screen] + [Vol+] for example
