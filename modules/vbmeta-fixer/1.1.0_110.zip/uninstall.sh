#!/system/bin/sh

ui_print "- Uninstalling service..."
pm uninstall com.reveny.vbmetafix.service
ui_print "- Uninstall done!"